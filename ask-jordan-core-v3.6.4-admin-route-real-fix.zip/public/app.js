const cfg=window.ASK_JORDAN_CONFIG;
const sb=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseKey);
const $=s=>document.querySelector(s);
let session=null,currentProfile=null,authMode='login',ads=[],editingAdId=null,currentDetail=null,currentImageIndex=0,isPublishing=false,currentConversationId=null,messageChannel=null,notificationChannel=null;
let favorites=new Set(JSON.parse(localStorage.getItem('askJordanFavorites')||'[]').map(Number));
let analytics=JSON.parse(localStorage.getItem('askJordanAnalytics')||'{}');
let buyerFlow={active:false,intent:null,step:null};
let currentSearch={query:'',intent:null,results:[]};
let sellerFlow={active:false,step:null,data:{}};
let selectedImageFingerprints=[];
const phoneToEmail=p=>`${String(p).replace(/\D/g,'')}@users.askjordan.com`;
const esc=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const money=v=>Number(v)?`${Number(v).toLocaleString('ar-JO')} د.أ`:'السعر عند التواصل';
const waLink=p=>`https://wa.me/962${String(p||'').replace(/\D/g,'').replace(/^0/,'')}`;
const normalizeImage=x=>x?{...x,image_url:x.image_url||x.url||''}:x;
const AD_DRAFT_KEY='askJordanAdDraftV160';
const PAYMENT_PHONE='0776275911';
const PROMOTION_PLANS={day:{label:'يوم واحد',amount:1,days:1},week:{label:'أسبوع',amount:5,days:7},month:{label:'شهر',amount:15,days:30}};
function detectCategoryFromText(text){
  const q=normalizeArabic(text);
  return Object.entries(categoryAliases).find(([,words])=>words.some(w=>q.includes(normalizeArabic(w))))?.[0]||'متفرقات';
}
function detectGovernorateFromText(text){
  const q=normalizeArabic(text);
  return Object.entries(governorateAliases).find(([,aliases])=>aliases.some(a=>q.includes(normalizeArabic(a))))?.[0]||'';
}
function detectPriceFromText(text){
  const q=normalizeArabic(text);
  const m=q.match(/(?:ب|بسعر|سعره|السعر|مطلوب)\s*([\d.,]+\s*(?:الف|k)?)/i)||q.match(/([\d.,]+\s*(?:الف|k)?)\s*(?:دينار|د\.?ا)/i);
  return m?parseCompactNumber(m[1]):null;
}
function buildSmartAd(text){
  const clean=String(text||'').trim();
  const category=detectCategoryFromText(clean),governorate=detectGovernorateFromText(clean),price=detectPriceFromText(clean);
  let title=clean.replace(/^(بدي|بدّي|اريد|أريد)\s+(ابيع|أبيع|بيع)\s*/i,'').split(/[،,.\n]/)[0].trim();
  title=title.replace(/(?:ب|بسعر|سعره|السعر|مطلوب)\s*[\d.,]+\s*(?:الف|k)?\s*(?:دينار|د\.?ا)?/ig,'').replace(/\s+(في|من)\s+(عمان|عمّان|اربد|إربد|الزرقاء|زرقاء|البلقاء|السلط|المفرق|جرش|عجلون|مادبا|الكرك|الطفيلة|معان|العقبة).*$/i,'').trim();
  if(title.length>100)title=title.slice(0,100).trim();
  if(!title)title=category==='متفرقات'?'منتج للبيع':category.replace(/ات$/,'');
  const areaMatch=clean.match(/(?:في|من)\s+(?:عمان|عمّان|اربد|إربد|الزرقاء|زرقاء|البلقاء|السلط|المفرق|جرش|عجلون|مادبا|الكرك|الطفيلة|معان|العقبة)\s+([^،,.\n]{2,30})/i);
  const area=areaMatch?.[1]?.replace(/^(منطقه|منطقة|حي)\s*/i,'').trim()||'';
  const description=clean.length<35?`${title} بحالة جيدة. للتواصل والاستفسار عبر الهاتف أو واتساب.`:clean;
  return {title,category,price:price||'',governorate,area,description};
}
function saveAdDraft(){
  const form=$('#adForm');if(!form)return;
  const e=form.elements;
  const draft={prompt:$('#sellerPrompt')?.value||'',title:e.title?.value||'',category:e.category?.value||'',price:e.price?.value||'',governorate:e.governorate?.value||'',area:e.area?.value||'',description:e.description?.value||'',phone:e.phone?.value||''};
  localStorage.setItem(AD_DRAFT_KEY,JSON.stringify(draft));
}
function restoreAdDraft(){
  try{const d=JSON.parse(localStorage.getItem(AD_DRAFT_KEY)||'null');if(!d)return false;const e=$('#adForm').elements;$('#sellerPrompt').value=d.prompt||'';for(const k of ['title','category','price','governorate','area','description','phone'])if(e[k]&&d[k]!==undefined)e[k].value=d[k];return true}catch{return false}
}
function clearAdDraft(){localStorage.removeItem(AD_DRAFT_KEY);$('#sellerPrompt').value='';$('#imagePreview').innerHTML='';}
function renderImagePreview(files){
  const box=$('#imagePreview');if(!box)return;box.innerHTML='';
  [...files].slice(0,5).forEach(file=>{const url=URL.createObjectURL(file),item=document.createElement('div');item.className='image-preview-item';item.innerHTML=`<img src="${url}" alt="معاينة"><span>${esc(file.name)}</span>`;box.appendChild(item)});
}

async function fileToVisionDataUrl(file,maxSide=1280,quality=.78){
  if(!file?.type?.startsWith('image/'))throw new Error('الملف المحدد ليس صورة.');
  const bitmap=await createImageBitmap(file),scale=Math.min(1,maxSide/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
  canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close?.();
  return canvas.toDataURL('image/jpeg',quality);
}
async function fileFingerprint(file){
  const head=await file.slice(0,Math.min(file.size,1024*1024)).arrayBuffer();
  const meta=new TextEncoder().encode(`${file.name}|${file.size}|${file.lastModified}|`),all=new Uint8Array(meta.length+head.byteLength);all.set(meta);all.set(new Uint8Array(head),meta.length);
  const digest=await crypto.subtle.digest('SHA-256',all);return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
async function detectDuplicateSelectedImages(files){
  const hashes=await Promise.all([...files].slice(0,5).map(fileFingerprint));selectedImageFingerprints=hashes;
  const seen=new Set(),duplicates=hashes.filter(h=>seen.has(h)||!seen.add(h));
  const published=new Set(JSON.parse(localStorage.getItem('askJordanPublishedImageHashes')||'[]'));
  const reused=hashes.filter(h=>published.has(h));
  const box=$('#duplicateImageWarning');if(!box)return;
  const messages=[];if(duplicates.length)messages.push('تم اختيار صورة مكررة أكثر من مرة.');if(reused.length)messages.push('بعض الصور استُخدمت سابقًا في إعلان من هذا الجهاز. تأكد أنك لا تنشر إعلانًا مكررًا.');
  box.textContent=messages.join(' ');box.hidden=!messages.length;
}
function rememberPublishedImageHashes(){
  if(!selectedImageFingerprints.length)return;const old=new Set(JSON.parse(localStorage.getItem('askJordanPublishedImageHashes')||'[]'));selectedImageFingerprints.forEach(x=>old.add(x));localStorage.setItem('askJordanPublishedImageHashes',JSON.stringify([...old].slice(-200)));
}
function marketPriceStats(category,title){
  const words=normalizeArabic(title).split(/\s+/).filter(x=>x.length>2).slice(0,5);
  let rows=ads.filter(a=>a.category===category&&Number(a.price)>0);
  const close=rows.filter(a=>words.some(w=>normalizeArabic(`${a.title} ${a.description||''}`).includes(w)));if(close.length>=2)rows=close;
  const prices=rows.map(a=>Number(a.price)).filter(Number.isFinite).sort((a,b)=>a-b);if(!prices.length)return null;
  const avg=prices.reduce((a,b)=>a+b,0)/prices.length;return{count:prices.length,min:prices[0],max:prices.at(-1),avg:Math.round(avg),quick:Math.round(avg*.92)};
}
function renderSmartPricing(aiPricing,stats){
  const box=$('#smartPricingResult');if(!box)return;if(!stats&&!aiPricing?.recommended){box.hidden=true;return}
  const recommended=aiPricing?.recommended||stats?.avg||null,quick=aiPricing?.quickSale||stats?.quick||null;
  $('#pricingMin').textContent=stats?money(stats.min):'—';$('#pricingAvg').textContent=stats?money(stats.avg):(recommended?money(recommended):'—');$('#pricingMax').textContent=stats?money(stats.max):'—';$('#pricingQuick').textContent=quick?money(quick):'—';
  $('#pricingConfidence').textContent=`ثقة ${aiPricing?.confidence||((stats?.count||0)>=5?'متوسطة':'منخفضة')}`;
  $('#pricingNote').textContent=aiPricing?.note||`المقارنة مبنية على ${stats?.count||0} إعلان مشابه داخل Ask Jordan، وهي تقديرية وليست تقييمًا فنيًا.`;box.hidden=false;
}

const saveFavorites=()=>localStorage.setItem('askJordanFavorites',JSON.stringify([...favorites]));
const isFavorite=id=>favorites.has(Number(id));
const saveAnalytics=()=>localStorage.setItem('askJordanAnalytics',JSON.stringify(analytics));
function trackAdAction(id,action){
  id=String(id);analytics[id]=analytics[id]||{views:0,whatsapp:0,calls:0,shares:0};
  analytics[id][action]=(analytics[id][action]||0)+1;saveAnalytics();
}
function adAnalytics(id){return analytics[String(id)]||{views:0,whatsapp:0,calls:0,shares:0}}
function toggleFavorite(id){
  id=Number(id);
  if(isFavorite(id))favorites.delete(id);else favorites.add(id);
  saveFavorites();
  renderAds(window.__lastRenderedAds||ads);
  if(currentDetail&&Number(currentDetail.id)===id)updateDetailFavorite();
}
function updateDetailFavorite(){
  const btn=$('#detailFavorite');
  if(!btn||!currentDetail)return;
  const active=isFavorite(currentDetail.id);
  btn.textContent=active?'♥ محفوظ':'♡ حفظ';
  btn.classList.toggle('active',active);
}
function animateNumber(el,target){
  if(!el)return;const start=Number(el.textContent.replace(/\D/g,''))||0,duration=700,t0=performance.now();
  const tick=now=>{const p=Math.min(1,(now-t0)/duration),v=Math.round(start+(target-start)*(1-Math.pow(1-p,3)));el.textContent=v.toLocaleString('ar-JO');if(p<1)requestAnimationFrame(tick)};requestAnimationFrame(tick)
}
async function loadPublicStats(countVisit=false){
  try{
    if(countVisit)await sb.rpc('increment_site_visit');
    const {data,error}=await sb.rpc('get_public_stats');if(error)throw error;
    const row=Array.isArray(data)?data[0]:data;if(!row)return;
    animateNumber($('#visitCount'),Number(row.visits)||0);animateNumber($('#searchCount'),Number(row.searches)||0);animateNumber($('#userCount'),Number(row.users)||0);animateNumber($('#activeAdCount'),Number(row.active_ads)||0);
  }catch(error){console.warn('Public stats:',error.message)}
}
function isFeatured(a){return a.featured_until&&new Date(a.featured_until)>new Date()}
function renderFeaturedAds(){
  const featured=ads.filter(isFeatured).sort((a,b)=>new Date(b.featured_until)-new Date(a.featured_until)).slice(0,6),section=$('#featuredSection');
  if(!section)return;section.hidden=!featured.length;if(!featured.length)return;
  $('#featuredAds').innerHTML=featured.map(a=>{const img=adImages(a)[0]?.image_url;return `<article class="card featured-card" data-featured-open="${a.id}"><span class="featured-badge">⭐ مميز</span><div class="card-media">${featured?'<span class="featured-badge">⭐ مميز</span>':''}${img?`<img src="${esc(img)}" alt="${esc(a.title)}" loading="lazy">`:'<div class="placeholder">📦</div>'}</div><div class="card-body"><h3>${esc(a.title)}</h3><div class="price">${money(a.price)}</div><div class="meta">📍 ${esc(a.governorate)}${a.area?` · ${esc(a.area)}`:''}</div></div></article>`}).join('');
  document.querySelectorAll('[data-featured-open]').forEach(c=>c.onclick=()=>openDetails(Number(c.dataset.featuredOpen)));
}
function openPromotionDialog(ad){
  $('#promotionAdId').value=ad.id;$('#promotionAdTitle').value=ad.title;$('#promotionStatus').hidden=true;$('#promotionDialog').showModal();
}
function closeDialogs(){document.querySelectorAll('dialog[open]').forEach(d=>d.close())}
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>document.getElementById(b.dataset.close).close());
async function refreshSession(){const {data}=await sb.auth.getSession();session=data.session;if(!session){currentProfile=null;updateAdminButton();return null}const {data:profile}=await sb.from('profiles').select('*').eq('id',session.user.id).maybeSingle();currentProfile=profile||null;updateAdminButton();return session}
function isAdmin(){return currentProfile?.role==='admin'}

const isAdminPath=()=>/^\/admin(?:\/login)?\/?$/.test(location.pathname);
function setAdminLoginStatus(message='',error=false){const box=$('#adminLoginStatus');if(!box)return;box.hidden=!message;box.textContent=message;box.classList.toggle('error',error)}
function openAdminLogin(message=''){
  const d=$('#adminLoginDialog');setAdminLoginStatus(message,Boolean(message));if(d&&!d.open)d.showModal();
}
async function handleAdminRoute(){
  if(!isAdminPath())return;
  await refreshSession();
  if(!session){openAdminLogin();return}
  if(!isAdmin()){openAdminLogin('هذا الحساب لا يملك صلاحية مشرف.');return}
  if(location.pathname!='/admin')history.replaceState(null,'','/admin');
  await openAdminPanel(true);
}

function updateAdminButton(){const btn=$('#adminBtn');if(btn)btn.hidden=!isAdmin()}
async function requireAuth(){await refreshSession();if(!session){setAuthMode('login');$('#authDialog').showModal();return false}return true}
async function requireAdmin(){await refreshSession();if(!session){setAuthMode('login');$('#authDialog').showModal();return false}if(!isAdmin()){alert('هذه الصفحة مخصصة للمشرف فقط.');return false}return true}
function setAuthMode(m){authMode=m;const s=m==='signup';$('#authTitle').textContent=s?'إنشاء حساب':'تسجيل الدخول';$('#authSubmit').textContent=s?'إنشاء الحساب':'دخول';$('#toggleAuth').textContent=s?'لدي حساب':'إنشاء حساب جديد';$('#nameField').hidden=!s}
$('#toggleAuth').onclick=()=>setAuthMode(authMode==='login'?'signup':'login');
$('#authForm').onsubmit=async e=>{e.preventDefault();const d=new FormData(e.currentTarget),phone=String(d.get('phone')).replace(/\D/g,''),password=String(d.get('password')),email=phoneToEmail(phone);let r;if(authMode==='signup'){r=await sb.auth.signUp({email,password,options:{data:{phone,name:String(d.get('name')||'')}}})}else{r=await sb.auth.signInWithPassword({email,password})}if(r.error){alert(r.error.message);return}await refreshSession();updateUnreadBadge();updateNotificationBadge();subscribeNotifications();closeDialogs();e.currentTarget.reset();alert(authMode==='signup'?'تم إنشاء الحساب':'تم تسجيل الدخول')};
async function fetchImages(){const {data,error}=await sb.from('ad_images').select('*').order('sort_order',{ascending:true});if(error){console.warn('Images load:',error.message);return []}return (data||[]).map(normalizeImage)}
let liveActivityOffset=0,liveActivityTimer=null;
function renderLiveActivity(){
  const section=$('#liveActivitySection'),box=$('#liveActivity');if(!section||!box)return;
  const recent=ads.slice(0,9);section.hidden=!recent.length;if(!recent.length)return;
  const now=Date.now(),visible=[];for(let i=0;i<Math.min(3,recent.length);i++)visible.push(recent[(liveActivityOffset+i)%recent.length]);
  box.innerHTML=visible.map((a,i)=>{const mins=Math.max(1,Math.floor((now-new Date(a.created_at||now).getTime())/60000));const label=mins<60?`قبل ${mins} دقيقة`:mins<1440?`قبل ${Math.floor(mins/60)} ساعة`:'اليوم';return `<button type="button" class="activity-item activity-enter" data-activity-ad="${a.id}"><span class="activity-icon">${i%2?'🔎':'✨'}</span><span><strong>${i===0?'وصل الآن':'إعلان جديد'}: ${esc(a.title)}</strong><small>${esc(a.governorate)} · ${label}</small></span></button>`}).join('');
  document.querySelectorAll('[data-activity-ad]').forEach(b=>b.onclick=()=>openDetails(Number(b.dataset.activityAd)));
  clearInterval(liveActivityTimer);if(recent.length>3)liveActivityTimer=setInterval(()=>{liveActivityOffset=(liveActivityOffset+1)%recent.length;renderLiveActivity()},6500);
}
async function loadAds(){
  $('#status').textContent='جاري تحميل الإعلانات...';
  const [{data:adRows,error:adError},images]=await Promise.all([
    sb.from('ads').select('*').eq('status','active').order('created_at',{ascending:false}).limit(200),
    fetchImages()
  ]);
  if(adError){$('#status').textContent=adError.message;return}
  const byAd=new Map();for(const img of images){if(!byAd.has(String(img.ad_id)))byAd.set(String(img.ad_id),[]);byAd.get(String(img.ad_id)).push(img)}
  ads=(adRows||[]).map(a=>({...a,ad_images:byAd.get(String(a.id))||[]})).sort((a,b)=>(isFeatured(b)-isFeatured(a))||new Date(b.created_at)-new Date(a.created_at));
  renderFeaturedAds();renderLiveActivity();renderAds(ads);loadPublicStats(false)
}
function adImages(a){return [...(a.ad_images||[])].map(normalizeImage).filter(x=>x.image_url).sort((x,y)=>(x.sort_order||0)-(y.sort_order||0))}
function renderAds(list){
  window.__lastRenderedAds=list;
  $('#status').textContent=list.length?`وجدنا ${list.length} إعلان`:'لا توجد إعلانات مطابقة حاليًا';
  $('#results').innerHTML=list.length?list.map(a=>{
    const imgs=adImages(a),img=imgs[0]?.image_url,fav=isFavorite(a.id),featured=isFeatured(a);
    return `<article class="card ${featured?'featured-card':''}" data-open-ad="${a.id}"><div class="card-media">${featured?'<span class="featured-badge">⭐ مميز</span>':''}${img?`<img src="${esc(img)}" alt="${esc(a.title)}" loading="lazy">`:'<div class="placeholder">📦</div>'}${imgs.length>1?`<span class="image-count">📷 ${imgs.length}</span>`:''}<button type="button" class="favorite-btn ${fav?'active':''}" data-favorite-ad="${a.id}" aria-label="حفظ الإعلان">${fav?'♥':'♡'}</button></div><div class="card-body"><div class="card-head"><h3>${esc(a.title)}</h3><button class="share-icon" data-share-ad="${a.id}" aria-label="مشاركة">↗</button></div><div class="price">${money(a.price)}</div><div class="meta">📍 ${esc(a.governorate)}${a.area?` · ${esc(a.area)}`:''}</div><p class="desc">${esc(a.description)}</p><div class="card-actions"><a class="call" href="tel:${esc(a.phone)}" data-track-call="${a.id}" onclick="event.stopPropagation()">اتصال</a><a class="whatsapp" target="_blank" rel="noopener" href="${waLink(a.phone)}" data-track-wa="${a.id}" onclick="event.stopPropagation()">واتساب</a></div></div></article>`;
  }).join(''):'<div class="empty">ما في نتائج حاليًا. جرّب طلبًا أوسع.</div>';
  document.querySelectorAll('[data-open-ad]').forEach(c=>c.onclick=e=>{if(e.target.closest('a,button'))return;openDetails(Number(c.dataset.openAd))});
  document.querySelectorAll('[data-share-ad]').forEach(b=>b.onclick=e=>{e.stopPropagation();shareAd(Number(b.dataset.shareAd))});
  document.querySelectorAll('[data-favorite-ad]').forEach(b=>b.onclick=e=>{e.stopPropagation();toggleFavorite(Number(b.dataset.favoriteAd))});
  document.querySelectorAll('[data-track-call]').forEach(a=>a.onclick=()=>trackAdAction(a.dataset.trackCall,'calls'));
  document.querySelectorAll('[data-track-wa]').forEach(a=>a.onclick=()=>trackAdAction(a.dataset.trackWa,'whatsapp'));
}
const governorates=['عمان','إربد','الزرقاء','البلقاء','المفرق','جرش','عجلون','مادبا','الكرك','الطفيلة','معان','العقبة'];
const governorateAliases={
  'عمان':['عمان','عمّان','amman'],
  'إربد':['إربد','اربد','irbid'],
  'الزرقاء':['الزرقاء','زرقاء','zarqa'],
  'البلقاء':['البلقاء','بلقاء','السلط','salt'],
  'المفرق':['المفرق','مفرق','mafraq'],
  'جرش':['جرش','jerash'],
  'عجلون':['عجلون','ajloun'],
  'مادبا':['مادبا','madaba'],
  'الكرك':['الكرك','كرك','karak'],
  'الطفيلة':['الطفيلة','طفيلة','tafilah'],
  'معان':['معان','maan'],
  'العقبة':['العقبة','عقبة','aqaba']
};
const categoryAliases={
  'سيارات':['سيارة','سيارات','سياره','مركبة','مركبات','تويوتا','كيا','هونداي','هيونداي','مرسيدس','bmw'],
  'موبايلات':['ايفون','آيفون','iphone','سامسونج','samsung','هاتف','موبايل','جوال','شاومي','xiaomi'],
  'عقارات':['شقة','شقق','بيت','منزل','أرض','ارض','عقار','عقارات','إيجار','ايجار','محل','مكتب'],
  'وظائف':['وظيفة','وظائف','شغل','عمل','موظف','موظفة'],
  'أثاث':['أثاث','اثاث','كنبايات','كنب','غرفة نوم','طاولة','خزانة'],
  'أجهزة كهربائية':['ثلاجة','غسالة','مكيف','تلفزيون','شاشة','أجهزة','اجهزة','فرن'],
  'خدمات':['خدمة','خدمات','صيانة','تنظيف','نقل','دهان','كهربجي','سباك']
};
const synonymGroups=[
  ['ايفون','آيفون','iphone'],['سامسونج','samsung'],['سيارة','سيارات','سياره'],['شقة','شقق','شقه'],
  ['موبايل','جوال','هاتف'],['إيجار','ايجار'],['أرض','ارض'],['أجهزة','اجهزة']
];
function normalizeArabic(v=''){
  return String(v).toLowerCase().normalize('NFKD').replace(/[\u064B-\u065F\u0670]/g,'').replace(/[إأآٱ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/[^\u0600-\u06FFa-z0-9.\s]/gi,' ').replace(/\s+/g,' ').trim();
}
function parseCompactNumber(raw){
  const s=String(raw).toLowerCase().replace(/,/g,'').trim();
  const m=s.match(/(\d+(?:\.\d+)?)\s*(الف|ألف|k)?/i);if(!m)return null;
  let n=Number(m[1]);if(m[2])n*=1000;return Number.isFinite(n)?n:null;
}
function expandWord(word){
  const n=normalizeArabic(word);const group=synonymGroups.find(g=>g.some(x=>normalizeArabic(x)===n));return group?group.map(normalizeArabic):[n];
}
function understandQuery(raw){
  const q=normalizeArabic(raw);
  const between=q.match(/(?:بين|من)\s*([\d.,]+\s*(?:الف|k)?)\s*(?:و|الى|ل)\s*([\d.,]+\s*(?:الف|k)?)/i);
  const maxM=q.match(/(?:اقل من|تحت|لحد|حده|حدود|ما يتجاوز|بسقف)\s*([\d.,]+\s*(?:الف|k)?)/i);
  const minM=q.match(/(?:اكثر من|فوق|يبدا من)\s*([\d.,]+\s*(?:الف|k)?)/i);
  let minPrice=between?parseCompactNumber(between[1]):minM?parseCompactNumber(minM[1]):null;
  let maxPrice=between?parseCompactNumber(between[2]):maxM?parseCompactNumber(maxM[1]):null;
  if(minPrice!==null&&maxPrice!==null&&minPrice>maxPrice)[minPrice,maxPrice]=[maxPrice,minPrice];
  const gov=Object.entries(governorateAliases).find(([,aliases])=>aliases.some(a=>q.includes(normalizeArabic(a))))?.[0]||null;
  const category=Object.entries(categoryAliases).find(([,words])=>words.some(w=>q.includes(normalizeArabic(w))))?.[0]||null;
  const yearMatch=q.match(/\b(19[8-9]\d|20[0-3]\d)\b/);
  const year=yearMatch?Number(yearMatch[1]):null;
  const transmission=/\b(اوتوماتيك|اوتوماتك|اتوماتيك|automatic)\b/.test(q)?'أوتوماتيك':/\b(عادي|يدوي|manual)\b/.test(q)?'عادي':null;
  const stop=['موديل','سنة','سنه','بدي','بدّي','اريد','أريد','دور','دورلي','ابحث','عن','اقل','اكثر','من','في','على','دينار','داخل','تحت','فوق','حدود','بحدود','ما','يتجاوز','بسعر','سعر','لحد','الى','بين','و'];
  const stopN=stop.map(normalizeArabic);
  const govTokens=Object.values(governorateAliases).flat().map(normalizeArabic);
  const words=q.split(/\s+/).filter(w=>w.length>1&&!stopN.includes(w)&&!govTokens.includes(w)&&!/^(\d|الف|k)/i.test(w));
  return {raw,q,minPrice,maxPrice,gov,category,year,transmission,words};
}
function scoreAd(a,intent){
  const hay=normalizeArabic(`${a.title} ${a.category} ${a.governorate} ${a.area} ${a.description}`);
  let score=0;
  if(intent.category){if(normalizeArabic(a.category)===normalizeArabic(intent.category))score+=35;else if(hay.includes(normalizeArabic(intent.category)))score+=15;else return -1}
  if(intent.gov){if(normalizeArabic(a.governorate)===normalizeArabic(intent.gov))score+=30;else if(hay.includes(normalizeArabic(intent.gov)))score+=12;else return -1}
  const price=Number(a.price)||0;
  if(intent.maxPrice!==null&&price>0){if(price>intent.maxPrice)return -1;score+=12-Math.min(10,Math.round((intent.maxPrice-price)/Math.max(intent.maxPrice,1)*10))}
  if(intent.minPrice!==null&&price<intent.minPrice)return -1;
  if(intent.year){if(hay.includes(String(intent.year)))score+=28;else return -1}
  if(intent.transmission){const variants=intent.transmission==='أوتوماتيك'?['اوتوماتيك','اوتوماتك','اتوماتيك','automatic']:['عادي','يدوي','manual'];if(variants.some(v=>hay.includes(normalizeArabic(v))))score+=24;else return -1}
  for(const word of intent.words){const variants=expandWord(word);if(variants.some(v=>hay.includes(v)))score+=18;else if(word.length>=4&&variants.some(v=>hay.split(' ').some(t=>t.startsWith(v.slice(0,Math.max(3,v.length-1))))))score+=8;else score-=5}
  if(a.created_at)score+=Math.max(0,5-Math.floor((Date.now()-new Date(a.created_at))/86400000/7));
  return score;
}
function searchAdsFromIntent(intent){return {intent,results:ads.map(a=>({a,score:scoreAd(a,intent)})).filter(x=>x.score>=0).sort((x,y)=>y.score-x.score).map(x=>x.a)}}
function searchAds(raw){return searchAdsFromIntent(understandQuery(raw))}
function serializeIntent(intent){return {category:intent?.category||null,gov:intent?.gov||null,minPrice:intent?.minPrice??null,maxPrice:intent?.maxPrice??null,year:intent?.year??null,transmission:intent?.transmission||null,words:Array.isArray(intent?.words)?intent.words:[]}}
function hydrateIntent(row){const x=row?.intent||{};return {raw:row?.query||'',q:normalizeArabic(row?.query||''),category:x.category||null,gov:x.gov||null,minPrice:x.minPrice??null,maxPrice:x.maxPrice??null,year:x.year??null,transmission:x.transmission||null,words:Array.isArray(x.words)?x.words:[]}}
async function saveCurrentSearch(){
  if(!currentSearch.query||!currentSearch.intent){alert('نفّذ بحثًا أولًا.');return}
  if(!await requireAuth())return;
  const payload={user_id:session.user.id,query:currentSearch.query,intent:serializeIntent(currentSearch.intent),last_seen_at:new Date().toISOString()};
  const {error}=await sb.from('saved_searches').insert(payload);
  if(error){if(error.code==='23505')alert('هذا البحث محفوظ عندك مسبقًا.');else alert(error.message);return}
  alert('تم حفظ البحث. سنظهر لك الإعلانات الجديدة المطابقة داخل حسابك.');
}
function bindSaveSearchButton(){const b=$('#saveSearchBtn');if(b)b.onclick=saveCurrentSearch}
async function callAskJordanAI(mode,text,extra={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),18000);
  try{
    const r=await fetch('/api/ai',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode,text,...extra}),signal:controller.signal});
    const payload=await r.json().catch(()=>({}));
    if(!r.ok||!payload.ok)throw new Error(payload.error||`AI HTTP ${r.status}`);
    return {...payload.data,__source:payload.source||'unknown',__model:payload.model||''};
  }finally{clearTimeout(timer)}
}
function compactAdForAgent(a){return {id:a.id,title:a.title,category:a.category,governorate:a.governorate,area:a.area,price:a.price,description:a.description}}
function reorderByAgent(results,rankedIds=[]){
  const order=new Map((rankedIds||[]).map((id,i)=>[String(id),i]));
  return [...results].sort((a,b)=>(order.has(String(a.id))?order.get(String(a.id)):999)-(order.has(String(b.id))?order.get(String(b.id)):999));
}
function mergeAIIntent(raw,ai){
  const local=understandQuery(raw),words=Array.isArray(ai?.keywords)?ai.keywords.map(normalizeArabic).filter(Boolean):[];
  return {...local,category:ai?.category||local.category,gov:ai?.governorate||local.gov,minPrice:Number.isFinite(Number(ai?.minPrice))?Number(ai.minPrice):local.minPrice,maxPrice:Number.isFinite(Number(ai?.maxPrice))?Number(ai.maxPrice):local.maxPrice,year:Number.isFinite(Number(ai?.year))?Number(ai.year):local.year,transmission:ai?.transmission||local.transmission,words:words.length?words:local.words,aiSummary:ai?.summary||'',aiReply:ai?.assistantReply||'',aiSource:ai?.__source||''};
}
function intentSummary(intent){const parts=[];if(intent.words.length)parts.push(intent.words.join(' '));if(intent.category&&!parts.includes(intent.category))parts.push(intent.category);if(intent.gov)parts.push(`في ${intent.gov}`);if(intent.year)parts.push(`موديل ${intent.year}`);if(intent.transmission)parts.push(intent.transmission);if(intent.minPrice!==null&&intent.maxPrice!==null)parts.push(`بين ${money(intent.minPrice)} و${money(intent.maxPrice)}`);else if(intent.maxPrice!==null)parts.push(`حتى ${money(intent.maxPrice)}`);else if(intent.minPrice!==null)parts.push(`من ${money(intent.minPrice)}`);return parts.join(' · ')||intent.raw}
function suggestionButtons(intent){
  const items=[];
  if(intent.maxPrice!==null)items.push({label:'وسّع السعر 20%',q:intent.raw.replace(/\d+(?:[.,]\d+)?\s*(?:الف|k)?/i,String(Math.round(intent.maxPrice*1.2)))})
  if(intent.gov)items.push({label:'كل الأردن',q:intent.raw.replace(new RegExp(governorateAliases[intent.gov].join('|'),'i'),'')})
  if(intent.words.length>1)items.push({label:'بحث أوسع',q:intent.words.slice(0,-1).join(' ')})
  return items.slice(0,3).map(x=>`<button type="button" class="suggestion-chip" data-search-suggestion="${esc(x.q.trim())}">${esc(x.label)}</button>`).join('');
}
async function runSmartSearch(raw,precomputedIntent=null,aiAlreadyUsed=false){
  sb.rpc('increment_search_count').then(()=>loadPublicStats(false)).catch(()=>{});
  const reply=$('#assistantReply');reply.hidden=false;reply.textContent='جاري فهم طلبك بالذكاء الاصطناعي...';
  let intent=precomputedIntent,usedAI=aiAlreadyUsed;
  if(!intent){
    try{const ai=await callAskJordanAI('search',raw);intent=mergeAIIntent(raw,ai);usedAI=true;console.info('Ask Jordan AI search active',ai)}
    catch(error){console.warn('AI fallback:',error.message);intent=understandQuery(raw)}
  }
  let {results}=searchAdsFromIntent(intent);
  const badge=usedAI?' <span class="ai-live-badge">AI</span>':'';
  const aiIntro=usedAI&&intent.aiReply?`${esc(intent.aiReply)}${badge}`:`فهمت طلبك${badge}: <strong>${esc(intent.aiSummary||intentSummary(intent))}</strong>`;
  let agentReply='',agentSuggestion='';
  if(usedAI){
    try{
      reply.innerHTML=`${aiIntro}<br>جاري مقارنة النتائج واختيار الأنسب إلك...`;
      const agent=await callAskJordanAI('agent',raw,{intent:{category:intent.category,governorate:intent.gov,minPrice:intent.minPrice,maxPrice:intent.maxPrice,year:intent.year,transmission:intent.transmission,keywords:intent.words},candidates:results.slice(0,15).map(compactAdForAgent)});
      results=reorderByAgent(results,agent.rankedIds);
      agentReply=agent.assistantReply||'';
      agentSuggestion=agent.suggestedQuery||'';
      console.info('Ask Jordan AI agent active',agent);
    }catch(error){console.warn('AI agent fallback:',error.message)}
  }
  const agentSuggestionHtml=agentSuggestion?`<div class="suggestion-row"><button type="button" class="suggestion-chip" data-search-suggestion="${esc(agentSuggestion)}">جرّب اقتراح الذكاء</button></div>`:'';
  reply.innerHTML=agentReply?`${esc(agentReply)}${badge}${agentSuggestionHtml}`:(results.length?`${aiIntro}<br>وجدت ورتبت لك <strong>${results.length}</strong> إعلانًا من الأكثر تطابقًا للأقل.`:`${aiIntro}<br>لكن ما لقيت إعلانًا مطابقًا حاليًا.${agentSuggestionHtml||`<div class="suggestion-row">${suggestionButtons(intent)}</div>`}`);
  currentSearch={query:raw,intent,results};
  renderAds(results);
  reply.insertAdjacentHTML('beforeend',`<div class="search-save-row"><button id="saveSearchBtn" type="button" class="save-search-btn">🔔 احفظ البحث ونبّهني</button></div>`);
  reply.insertAdjacentHTML('beforeend',assistantActionBar());
  bindSaveSearchButton();bindAssistantActions();
  document.querySelectorAll('[data-search-suggestion]').forEach(b=>b.onclick=()=>{$('#searchInput').value=b.dataset.searchSuggestion;$('#searchForm').requestSubmit()});
}

function assistantActionBar(){
  if(!currentSearch?.results?.length)return '';
  return `<div class="assistant-action-bar">
    <button type="button" data-ai-action="compare">⚖️ قارن أفضل 3</button>
    <button type="button" data-ai-action="cheapest">💰 الأرخص</button>
    <button type="button" data-ai-action="newest">🕒 الأحدث</button>
    <button type="button" data-ai-action="expand">🔎 وسّع البحث</button>
  </div>`;
}
function bindAssistantActions(){
  document.querySelectorAll('[data-ai-action]').forEach(b=>b.onclick=()=>handleResultAssistantAction(b.dataset.aiAction));
}
async function handleResultAssistantAction(action){
  if(!currentSearch?.results?.length){appendBuyerMessage('اعمل بحث أولًا، وبعدها بقدر أقارن وأرتّب النتائج إلك.');return}
  if(action==='cheapest'){
    const rows=[...currentSearch.results].sort((a,b)=>(Number(a.price)||Infinity)-(Number(b.price)||Infinity));
    currentSearch.results=rows;renderAds(rows);appendBuyerMessage(`رتبت لك النتائج من الأرخص للأعلى. أول نتيجة سعرها <strong>${money(rows[0]?.price)}</strong>.${assistantActionBar()}`);bindAssistantActions();return;
  }
  if(action==='newest'){
    const rows=[...currentSearch.results].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
    currentSearch.results=rows;renderAds(rows);appendBuyerMessage(`رتبت لك النتائج من الأحدث للأقدم.${assistantActionBar()}`);bindAssistantActions();return;
  }
  if(action==='expand'){
    const i={...currentSearch.intent};
    if(i.maxPrice!==null)i.maxPrice=Math.round(i.maxPrice*1.15);
    else if(i.gov)i.gov=null;
    else{i.words=(i.words||[]).slice(0,-1)}
    const q=intentToQuery(i)||currentSearch.query;
    appendBuyerMessage(`وسّعت البحث شوي حتى نجيب خيارات أكثر: <strong>${esc(intentSummary(i))}</strong>`);
    buyerFlow={active:true,intent:i,step:'done'};await runSmartSearch(q,i,false);return;
  }
  if(action==='compare'){
    const top=currentSearch.results.slice(0,3);
    appendBuyerMessage('لحظة، بقارن أفضل الخيارات حسب السعر والموقع والوصف...');
    try{
      const r=await callAskJordanAI('compare',currentSearch.query,{candidates:top.map(compactAdForAgent)});
      appendBuyerMessage(`<strong>المقارنة الذكية:</strong><br>${esc(r.assistantReply||'تعذرت المقارنة.').replace(/\n/g,'<br>')}${assistantActionBar()}`);
    }catch(error){
      const lines=top.map((a,i)=>`${i+1}. ${esc(a.title)} — ${money(a.price)} — ${esc(a.governorate||'')}`).join('<br>');
      appendBuyerMessage(`<strong>أفضل 3 نتائج:</strong><br>${lines}<br><small>تمت المقارنة محليًا لأن خدمة الذكاء غير متاحة مؤقتًا.</small>${assistantActionBar()}`);
    }
    bindAssistantActions();
  }
}
function detectContextCommand(raw){
  const n=normalizeArabic(raw);
  if(/قارن|مقارنه|افضل ثلاث|افضل 3/.test(n))return 'compare';
  if(/الارخص|ارخص/.test(n))return 'cheapest';
  if(/الاحدث|احدث|جديد/.test(n))return 'newest';
  if(/وسع|توسيع|خيارات اكثر|نتائج اكثر/.test(n))return 'expand';
  return null;
}
function appendBuyerMessage(text,kind='assistant'){
  const box=$('#buyerConversation');if(!box)return;
  const msg=document.createElement('div');msg.className=`buyer-message ${kind}`;msg.innerHTML=kind==='assistant'?text:esc(text);box.appendChild(msg);box.scrollTop=box.scrollHeight;
}
function setBuyerChoices(items=[]){
  const box=$('#buyerChoices');if(!box)return;box.hidden=!items.length;
  box.innerHTML=items.map(x=>`<button type="button" data-buyer-choice="${esc(x.value)}">${esc(x.label)}</button>`).join('');
  box.querySelectorAll('[data-buyer-choice]').forEach(b=>b.onclick=()=>handleBuyerInput(b.dataset.buyerChoice,true));
}
function resetBuyerFlow(showGreeting=true){
  buyerFlow={active:false,intent:null,step:null};setBuyerChoices([]);$('#resetBuyerFlow').hidden=true;
  if(showGreeting){$('#buyerConversation').innerHTML='<div class="buyer-message assistant">مرحبًا 👋 اكتب ما تبحث عنه، مثل: <strong>بدي سيارة</strong>.</div>'}
}
function intentToQuery(intent){
  const parts=[];
  if(intent.words?.length)parts.push(intent.words.join(' '));else if(intent.category)parts.push(intent.category);
  if(intent.year)parts.push(String(intent.year));if(intent.transmission)parts.push(intent.transmission);if(intent.maxPrice!==null)parts.push(`أقل من ${intent.maxPrice}`);if(intent.minPrice!==null)parts.push(`أكثر من ${intent.minPrice}`);if(intent.gov)parts.push(`في ${intent.gov}`);
  return parts.join(' ').trim();
}
function askNextBuyerQuestion(){
  const intent=buyerFlow.intent;
  $('#resetBuyerFlow').hidden=false;
  if(!intent.category){buyerFlow.step='category';appendBuyerMessage('شو نوع الشيء اللي بتدور عليه؟');setBuyerChoices(Object.keys(categoryAliases).map(x=>({label:x,value:x})));return}
  if(!intent.gov){buyerFlow.step='gov';appendBuyerMessage('ممتاز 👌 بأي محافظة بدك تبحث؟');setBuyerChoices(governorates.map(x=>({label:x,value:x})));return}
  if(intent.category==='سيارات'&&!intent.transmission){buyerFlow.step='transmission';appendBuyerMessage('بدك السيارة أوتوماتيك ولا عادي؟');setBuyerChoices([{label:'أوتوماتيك',value:'أوتوماتيك'},{label:'عادي',value:'عادي'},{label:'ما بفرق',value:'ما بفرق'}]);return}
  if(intent.maxPrice===null&&intent.minPrice===null&&['سيارات','موبايلات','عقارات','أثاث','أجهزة كهربائية'].includes(intent.category)){buyerFlow.step='price';appendBuyerMessage('شو أعلى ميزانية مناسبة إلك؟ اكتب الرقم بالدينار، أو اختر بدون تحديد.');setBuyerChoices([{label:'بدون تحديد سعر',value:'بدون تحديد'},{label:'أقل من 300',value:'300'},{label:'أقل من 1000',value:'1000'},{label:'أقل من 10000',value:'10000'}]);return}
  buyerFlow.step='done';setBuyerChoices([]);const query=intentToQuery(intent);appendBuyerMessage(`تمام، ببحث لك عن: <strong>${esc(intentSummary(intent))}</strong>`);runSmartSearch(query);document.querySelector('#conversation')?.scrollIntoView({behavior:'smooth',block:'start'});
}
function mergeBuyerAnswer(raw){
  const answer=understandQuery(raw),intent=buyerFlow.intent;
  if(buyerFlow.step==='category')intent.category=answer.category||Object.keys(categoryAliases).find(x=>normalizeArabic(x)===normalizeArabic(raw))||intent.category;
  else if(buyerFlow.step==='gov')intent.gov=answer.gov||governorates.find(x=>normalizeArabic(x)===normalizeArabic(raw))||intent.gov;
  else if(buyerFlow.step==='transmission'){intent.transmission=/فرق/.test(raw)?null:(answer.transmission||raw);}
  else if(buyerFlow.step==='price'){
    if(normalizeArabic(raw).includes('بدون تحديد')){intent.maxPrice=null;intent.minPrice=null;intent.skipPrice=true}
    else{const n=parseCompactNumber(raw);if(n!==null)intent.maxPrice=n}
  }
  if(answer.words?.length&&buyerFlow.step!=='category'&&buyerFlow.step!=='gov')intent.words=[...new Set([...(intent.words||[]),...answer.words])];
}
async function handleBuyerInput(raw,fromChoice=false){
  raw=String(raw||'').trim();if(!raw)return;
  appendBuyerMessage(raw,'user');$('#searchInput').value='';
  const normalized=normalizeArabic(raw);
  if(/\b(ابيع|بيع|اعرض|انشر)\b/.test(normalized)||normalized==='بدي ابيع'){
    appendBuyerMessage('أكيد 👍 افتح لك نموذج الإعلان، ومساعد البيع سيعبّيه معك.');setBuyerChoices([]);if(await requireAuth()){$('#heroAddBtn').click()}return;
  }
  const contextAction=detectContextCommand(raw);
  if(contextAction&&currentSearch?.results?.length){await handleResultAssistantAction(contextAction);return}
  if(buyerFlow.active&&buyerFlow.step!=='done'){mergeBuyerAnswer(raw);askNextBuyerQuestion();return}
  let intent,usedAI=false;
  appendBuyerMessage('لحظة، بفهم طلبك بالذكاء الاصطناعي...');
  try{
    const ai=await callAskJordanAI('search',raw);
    intent=mergeAIIntent(raw,ai);
    usedAI=true;
    console.info('Ask Jordan AI buyer flow active',ai);
  }catch(error){
    console.warn('AI buyer-flow fallback:',error.message);
    intent=understandQuery(raw);
    appendBuyerMessage('خدمة الذكاء غير متاحة مؤقتًا، بكمل معك بالنظام المحلي.');
  }
  buyerFlow={active:true,intent,step:null};$('#resetBuyerFlow').hidden=false;
  const enoughDetail=Boolean(intent.category&&intent.gov&&(intent.maxPrice!==null||intent.minPrice!==null||!['سيارات','موبايلات','عقارات','أثاث','أجهزة كهربائية'].includes(intent.category)));
  if(enoughDetail){appendBuyerMessage(`فهمت طلبك${usedAI?' بالذكاء الاصطناعي':''}: <strong>${esc(intent.aiSummary||intentSummary(intent))}</strong>`);buyerFlow.step='done';runSmartSearch(raw,intent,usedAI);document.querySelector('#conversation')?.scrollIntoView({behavior:'smooth',block:'start'});return}
  askNextBuyerQuestion();
}
$('#searchForm').onsubmit=e=>{e.preventDefault();handleBuyerInput($('#searchInput').value)};
document.querySelectorAll('[data-prompt]').forEach(b=>b.onclick=()=>handleBuyerInput(b.dataset.prompt,true));
$('#resetBuyerFlow').onclick=()=>{resetBuyerFlow(true);$('#searchInput').focus()};
function appendSellerMessage(text,kind='assistant'){
  const box=$('#sellerConversation');if(!box)return;const m=document.createElement('div');m.className=`seller-message ${kind}`;m.innerHTML=kind==='assistant'?text:esc(text);box.appendChild(m);box.scrollTop=box.scrollHeight;
}
function setSellerChoices(items=[]){
  const box=$('#sellerChoices');if(!box)return;box.innerHTML=items.map(x=>`<button type="button" data-seller-choice="${esc(x.value)}">${esc(x.label)}</button>`).join('');
  box.querySelectorAll('[data-seller-choice]').forEach(b=>b.onclick=()=>handleSellerWizardAnswer(b.dataset.sellerChoice));
}
function resetSellerWizard(){
  sellerFlow={active:true,step:'title',data:{}};
  if($('#sellerConversation'))$('#sellerConversation').innerHTML='<div class="seller-message assistant">شو بدك تبيع اليوم؟</div>';
  setSellerChoices([{label:'📱 موبايل',value:'موبايل'},{label:'🚗 سيارة',value:'سيارة'},{label:'🏠 عقار',value:'عقار'},{label:'🪑 أثاث',value:'أثاث'}]);
  if($('#sellerWizardInput')){$('#sellerWizardInput').value='';$('#sellerWizardInput').placeholder='مثال: آيفون 14 برو'}
}
function wizardCategory(value){return detectCategoryFromText(value)||'متفرقات'}
function finishSellerWizard(){
  const e=$('#adForm').elements,d=sellerFlow.data;
  e.title.value=d.title||'';e.category.value=d.category||wizardCategory(d.title||'');e.price.value=d.price||'';if(d.governorate)e.governorate.value=d.governorate;e.area.value=d.area||'';e.description.value=d.description||`${d.title||'المنتج'} بحالة جيدة. للتواصل والاستفسار عبر الهاتف أو واتساب.`;
  appendSellerMessage('تم تجهيز الإعلان ✅ راجع البيانات والصور ثم اضغط <strong>نشر الإعلان</strong>.');setSellerChoices([]);sellerFlow.step='done';saveAdDraft();
}
function handleSellerWizardAnswer(raw){
  const value=String(raw||'').trim();if(!value||sellerFlow.step==='done')return;appendSellerMessage(value,'user');const input=$('#sellerWizardInput');if(input)input.value='';
  const d=sellerFlow.data;
  if(sellerFlow.step==='title'){
    d.title=value;d.category=wizardCategory(value);sellerFlow.step='price';appendSellerMessage('كم السعر؟ اكتب الرقم أو اختر قابل للتفاوض.');setSellerChoices([{label:'قابل للتفاوض',value:'قابل للتفاوض'},{label:'50 د.أ',value:'50'},{label:'100 د.أ',value:'100'},{label:'500 د.أ',value:'500'}]);if(input)input.placeholder='مثال: 450';return;
  }
  if(sellerFlow.step==='price'){
    d.price=/تفاوض/.test(value)?'':parseCompactNumber(value)||'';sellerFlow.step='governorate';appendSellerMessage('بأي محافظة؟');setSellerChoices(governorates.map(g=>({label:g,value:g})));if(input)input.placeholder='اكتب المحافظة';return;
  }
  if(sellerFlow.step==='governorate'){
    d.governorate=detectGovernorateFromText(value)||value;sellerFlow.step='area';appendSellerMessage('شو المنطقة أو الحي؟');setSellerChoices([]);if(input)input.placeholder='مثال: الحي الشرقي';return;
  }
  if(sellerFlow.step==='area'){
    d.area=value;sellerFlow.step='description';appendSellerMessage('احكيلي أهم التفاصيل والحالة.');setSellerChoices([{label:'جديد',value:'جديد ولم يُستخدم'},{label:'مستعمل بحالة ممتازة',value:'مستعمل بحالة ممتازة'},{label:'بحالة جيدة',value:'بحالة جيدة'}]);if(input)input.placeholder='مثال: نظيف جدًا ومعه الكرتونة';return;
  }
  if(sellerFlow.step==='description'){d.description=value;finishSellerWizard()}
}
function resetAdForm(){editingAdId=null;selectedImageFingerprints=[];if($('#smartPricingResult'))$('#smartPricingResult').hidden=true;if($('#duplicateImageWarning'))$('#duplicateImageWarning').hidden=true;if($('#visionStatus'))$('#visionStatus').textContent='';if($('#aiAdResult'))$('#aiAdResult').hidden=true;if($('#moderationResult'))$('#moderationResult').hidden=true;if($('#aiPolishResult'))$('#aiPolishResult').hidden=true;if($('#aiPolishStatus'))$('#aiPolishStatus').textContent='';$('#adDialogTitle').textContent='إضافة إعلان';$('#adSubmit').textContent='نشر الإعلان';$('#adImagesHint').hidden=true;$('#publishStatus').hidden=true;$('#adForm').reset();$('#imagePreview').innerHTML='';$('#sellerAssistantStatus').textContent='';restoreAdDraft();resetSellerWizard()}
function renderAIAdResult(r={}){const box=$('#aiAdResult');if(!box)return;const score=Math.max(0,Math.min(100,Number(r.qualityScore)||0));$('#aiQualityScore').textContent=`${score}/100`;$('#aiQualityBar').style.width=`${score}%`;const meta=[r.brand&&`الماركة: ${r.brand}`,r.model&&`الموديل: ${r.model}`,r.condition&&`الحالة: ${r.condition}`].filter(Boolean);$('#aiExtractedMeta').innerHTML=meta.map(x=>`<span>${esc(x)}</span>`).join('');$('#aiTags').innerHTML=(r.tags||[]).map(x=>`<span>#${esc(x)}</span>`).join('');$('#aiQualityTips').innerHTML=(r.qualityTips||[]).map(x=>`<li>${esc(x)}</li>`).join('');box.hidden=false}
$('#generateAdBtn').onclick=async()=>{const text=$('#sellerPrompt').value.trim(),status=$('#sellerAssistantStatus'),btn=$('#generateAdBtn');if(!text){status.textContent='اكتب وصفًا سريعًا للإعلان أولًا.';return}btn.disabled=true;btn.textContent='جاري التحليل...';status.textContent='جاري إنشاء مسودة الإعلان وتحليل جودتها...';$('#aiAdResult').hidden=true;try{let r;try{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),20000);const res=await fetch('/api/ai/generate-ad',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text}),signal:controller.signal});clearTimeout(timer);const payload=await res.json().catch(()=>({}));if(!res.ok||!payload.ok)throw new Error(payload.error||`AI HTTP ${res.status}`);r=payload.data;console.info('Ask Jordan AI Seller Assistant active',r)}catch(error){console.warn('AI ad fallback:',error.message);r={...buildSmartAd(text),qualityScore:55,qualityTips:['أضف تفاصيل أكثر عن الحالة','أضف الماركة أو الموديل إن وجد','أرفق صورًا واضحة'],tags:[]};status.textContent='تمت التعبئة بالنظام المحلي لأن خدمة الذكاء غير متاحة مؤقتًا.'}const e=$('#adForm').elements;e.title.value=r.title||'';if(r.category&&[...e.category.options].some(o=>o.value===r.category))e.category.value=r.category;if(r.price!==null&&r.price!==undefined)e.price.value=r.price;if(r.governorate&&[...e.governorate.options].some(o=>o.value===r.governorate))e.governorate.value=r.governorate;if(r.area)e.area.value=r.area;e.description.value=r.description||text;renderAIAdResult(r);if(!status.textContent.includes('النظام المحلي'))status.textContent='تم إنشاء المسودة بالذكاء الاصطناعي. راجع البيانات قبل النشر.';saveAdDraft()}catch(error){status.textContent=error.message||'تعذر تجهيز الإعلان.'}finally{btn.disabled=false;btn.textContent='تعبئة الإعلان تلقائيًا'}};
function currentAdForAI(){const e=$('#adForm').elements;return{title:e.title.value.trim(),category:e.category.value,price:Number(e.price.value)||null,governorate:e.governorate.value,area:e.area.value.trim(),description:e.description.value.trim()}}
function localQualityStudio(ad,action){const title=ad.title||'',description=ad.description||'';const parts={title:Math.min(100,title.length*5),description:Math.min(100,description.length/3),details:0,price:ad.price?100:45,location:ad.area?100:55};parts.details=Math.min(100,(description.match(/\d+|جديد|مستعمل|نظيف|ضمان|موديل|مساحة|سنة|لون/gi)||[]).length*18);const score=Math.round((parts.title+parts.description+parts.details+parts.price+parts.location)/5),tips=[];if(title.length<18)tips.push('اجعل العنوان أوضح وأضف الماركة أو الموديل.');if(description.length<120)tips.push('أضف تفاصيل أكثر عن الحالة والمواصفات.');if(!ad.price)tips.push('إضافة سعر واضح تزيد فرص التواصل.');if(action==='improve')return{title:title||'منتج للبيع بحالة جيدة',description:description?`${description.replace(/\s+/g,' ').trim()}\n\nالمعاينة متاحة، وللتواصل والاستفسار يرجى مراسلة البائع عبر المنصة.`:'المنتج متوفر للبيع بحالة جيدة. يرجى التواصل لمعرفة التفاصيل والمعاينة.',qualityScore:Math.min(90,score+12),tips};if(action==='translate')return{translatedTitle:title,translatedDescription:description,language:'en',note:'تعذرت الترجمة السحابية؛ تم الإبقاء على النص الأصلي.'};if(action==='seo'){const slug=title.toLowerCase().replace(/[^\u0600-\u06ff\w]+/g,'-').replace(/^-|-$/g,'').slice(0,70)||'ad';return{metaTitle:`${title} | Ask Jordan`.slice(0,60),metaDescription:(description||`${title} للبيع في ${ad.governorate}`).slice(0,155),slug,keywords:[ad.category,ad.governorate,...title.split(/\s+/).slice(0,4)].filter(Boolean)}}return{qualityScore:score,breakdown:parts,tips}}
async function runQualityStudio(action,button){const status=$('#aiPolishStatus'),box=$('#aiPolishResult'),summary=$('#aiPolishSummary'),seo=$('#seoPreview'),ad=currentAdForAI();if(!ad.title&&!ad.description){status.textContent='اكتب عنوانًا أو وصفًا أولًا.';return}const old=button.textContent;button.disabled=true;button.textContent='جاري المعالجة...';status.textContent='يعمل المساعد على الإعلان...';box.hidden=true;seo.hidden=true;try{let r;try{const res=await fetch('/api/ai',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:'polish',action,ad})});const payload=await res.json().catch(()=>({}));if(!res.ok||!payload.ok)throw new Error(payload.error||`AI HTTP ${res.status}`);r=payload.data}catch(error){console.warn('AI quality studio fallback:',error.message);r=localQualityStudio(ad,action);status.textContent='تم استخدام التحليل المحلي مؤقتًا.'}const e=$('#adForm').elements;if(action==='improve'){if(r.title)e.title.value=r.title;if(r.description)e.description.value=r.description;renderAIAdResult({qualityScore:r.qualityScore||0,qualityTips:r.tips||[],tags:r.tags||[]});summary.innerHTML=`<strong>تم تحسين الإعلان</strong><p>${esc(r.summary||'تمت إعادة صياغة العنوان والوصف مع الحفاظ على المعلومات الأصلية.')}</p>`;saveAdDraft()}else if(action==='score'){const b=r.breakdown||{};summary.innerHTML=`<div class="ai-score-head"><strong>Quality Score</strong><span>${Number(r.qualityScore||0)}/100</span></div><div class="quality-breakdown"><div><small>العنوان</small><strong>${Number(b.title||0)}/100</strong></div><div><small>الوصف</small><strong>${Number(b.description||0)}/100</strong></div><div><small>التفاصيل</small><strong>${Number(b.details||0)}/100</strong></div><div><small>السعر والموقع</small><strong>${Math.round((Number(b.price||0)+Number(b.location||0))/2)}/100</strong></div></div><ul>${(r.tips||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`}else if(action==='translate'){summary.innerHTML=`<strong>${esc(r.translatedTitle||'English translation')}</strong><p dir="ltr">${esc(r.translatedDescription||'')}</p><button type="button" id="applyTranslationBtn" class="ghost">استخدام الترجمة في الإعلان</button>`;setTimeout(()=>{const x=$('#applyTranslationBtn');if(x)x.onclick=()=>{e.title.value=r.translatedTitle||e.title.value;e.description.value=r.translatedDescription||e.description.value;saveAdDraft();status.textContent='تم تطبيق الترجمة.'}},0)}else if(action==='seo'){$('#seoTitle').textContent=r.metaTitle||ad.title;$('#seoSlug').textContent=`askjordan.com/ad/${r.slug||'ad'}`;$('#seoDescription').textContent=r.metaDescription||ad.description;seo.hidden=false;summary.innerHTML=`<strong>تم تجهيز SEO</strong><p>الكلمات المفتاحية: ${(r.keywords||[]).map(esc).join('، ')||'—'}</p>`}box.hidden=false;if(!status.textContent.includes('المحلي'))status.textContent='تمت العملية بنجاح.'}catch(error){status.textContent=error.message||'تعذرت العملية.'}finally{button.disabled=false;button.textContent=old}}
$('#improveAdBtn').onclick=e=>runQualityStudio('improve',e.currentTarget);$('#scoreAdBtn').onclick=e=>runQualityStudio('score',e.currentTarget);$('#translateAdBtn').onclick=e=>runQualityStudio('translate',e.currentTarget);$('#seoAdBtn').onclick=e=>runQualityStudio('seo',e.currentTarget);
$('#clearDraftBtn').onclick=()=>{clearAdDraft();$('#adForm').reset();$('#sellerAssistantStatus').textContent='تم مسح المسودة.'};
$('#sellerWizardSend').onclick=()=>handleSellerWizardAnswer($('#sellerWizardInput').value);
$('#sellerWizardInput').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();handleSellerWizardAnswer(e.currentTarget.value)}};
$('#adImagesInput').addEventListener('change',async e=>{renderImagePreview(e.target.files);try{await detectDuplicateSelectedImages(e.target.files)}catch(error){console.warn('Image fingerprint:',error)}});
$('#analyzeImagesBtn').onclick=async()=>{
  const input=$('#adImagesInput'),files=[...input.files].slice(0,3),btn=$('#analyzeImagesBtn'),status=$('#visionStatus');
  if(!files.length){status.textContent='اختر صورة واحدة على الأقل أولًا.';return}
  btn.disabled=true;btn.textContent='جاري تحليل الصور...';status.textContent='يتم الآن فهم المنتج وجودة الصور ومقارنة السعر...';
  try{
    const images=[];for(const file of files)images.push(await fileToVisionDataUrl(file));
    const e=$('#adForm').elements,text=$('#sellerPrompt').value.trim()||`${e.title.value||''} ${e.description.value||''}`.trim();
    const market=ads.filter(a=>Number(a.price)>0).slice(0,40).map(a=>({id:a.id,title:a.title,category:a.category,price:a.price,governorate:a.governorate,description:a.description}));
    const res=await fetch('/api/ai',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:'vision',text,images,market})});
    const payload=await res.json().catch(()=>({}));if(!res.ok||!payload.ok)throw new Error(payload.error||`AI HTTP ${res.status}`);const r=payload.data;
    if(r.title&&!e.title.value)e.title.value=r.title;if(r.category&&[...e.category.options].some(o=>o.value===r.category))e.category.value=r.category;if(r.description&&!e.description.value)e.description.value=r.description;
    renderAIAdResult({...r,qualityTips:[...(r.qualityTips||[]),r.imageQualityScore?`جودة الصور: ${r.imageQualityScore}/100`:null].filter(Boolean)});
    const meta=$('#aiExtractedMeta'),extra=[r.color&&`اللون: ${r.color}`,r.detectedMultipleProducts&&'تنبيه: يظهر أكثر من منتج في الصور'].filter(Boolean);meta.innerHTML+=extra.map(x=>`<span>${esc(x)}</span>`).join('');
    const stats=marketPriceStats(r.category||e.category.value,r.title||e.title.value);renderSmartPricing(r.pricing,stats);
    status.textContent=r.detectedMultipleProducts?'تم التحليل، لكن يظهر أكثر من منتج. يفضّل تخصيص إعلان لكل منتج.':'تم تحليل الصور وتعبئة البيانات المتاحة. راجعها قبل النشر.';saveAdDraft();
  }catch(error){console.error('Vision analysis:',error);status.textContent=error.message||'تعذر تحليل الصور.'}
  finally{btn.disabled=false;btn.textContent='📷 تحليل الصور بالذكاء الاصطناعي'}
};
$('#adForm').addEventListener('input',()=>{clearTimeout(window.__draftTimer);window.__draftTimer=setTimeout(saveAdDraft,350)});
$('#addBtn').onclick=async()=>{if(!await requireAuth())return;resetAdForm();const {data:p}=await sb.from('profiles').select('phone').eq('id',session.user.id).single();$('#adForm').elements.phone.value=p?.phone||'';$('#adDialog').showModal()};
async function insertImageRow(row){let r=await sb.from('ad_images').insert({...row,image_url:row.image_url});if(!r.error)return r; if(/image_url/i.test(r.error.message||'')){const {image_url,...rest}=row;return await sb.from('ad_images').insert({...rest,url:image_url})}return r}
async function uploadImages(adId,files){let uploaded=0;for(let i=0;i<files.length;i++){const f=files[i];if(f.size>5*1024*1024)throw new Error(`الصورة ${f.name} أكبر من 5MB`);const ext=(f.name.split('.').pop()||'jpg').toLowerCase(),path=`${session.user.id}/${adId}/${crypto.randomUUID()}.${ext}`;const up=await sb.storage.from('ad-images').upload(path,f,{cacheControl:'3600',upsert:false});if(up.error)throw up.error;const {data:urlData}=sb.storage.from('ad-images').getPublicUrl(path);const imageRow={ad_id:adId,image_url:urlData.publicUrl,sort_order:i};const saved=await insertImageRow(imageRow);if(saved.error)throw saved.error;uploaded++}return uploaded}
async function verifyAd(adId){const {data,error}=await sb.from('ads').select('*').eq('id',adId).in('status',['active','under_review']).single();if(error||!data)throw new Error('تم إرسال الطلب لكن لم يتم تأكيد حفظ الإعلان. حاول مرة أخرى.');return data}
function normalizeWords(v){return String(v||'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim().split(/\s+/).filter(x=>x.length>2)}
function localModeration(ad,candidates=[]){const text=`${ad.title} ${ad.description}`.toLowerCase();let risk=0,reasons=[];const risky=[['عربون',24],['تحويل مسبق',28],['حوّل',16],['واتساب فقط',9],['فرصة لا تتكرر',8],['مضمون 100',12],['بدون فحص',10]];for(const [w,n] of risky)if(text.includes(w)){risk+=n;reasons.push(`يحتوي النص على عبارة تحتاج تحقق: ${w}`)}const aw=new Set(normalizeWords(`${ad.title} ${ad.description}`));let best={score:0,id:null,reason:''};for(const c of candidates){if(editingAdId&&Number(c.id)===Number(editingAdId))continue;const cw=new Set(normalizeWords(`${c.title} ${c.description}`));const common=[...aw].filter(x=>cw.has(x)).length;const union=new Set([...aw,...cw]).size||1;let score=Math.round(common/union*100);if(ad.phone&&c.phone===ad.phone)score+=18;if(ad.category===c.category)score+=7;if(ad.governorate===c.governorate&&ad.area===c.area)score+=7;if(ad.price&&c.price&&Math.abs(ad.price-c.price)/Math.max(ad.price,c.price)<.05)score+=8;score=Math.min(100,score);if(score>best.score)best={score,id:c.id,reason:'تشابه في النص والبيانات الأساسية'}}if(best.score>=78){risk=Math.max(risk,48);reasons.push('يوجد إعلان مشابه بدرجة مرتفعة.')}risk=Math.min(100,risk);return{riskScore:risk,trustScore:100-risk,riskLevel:risk>=70?'مرتفع':risk>=35?'متوسط':'منخفض',action:risk>=80?'block':risk>=45?'review':'allow',reasons:reasons.slice(0,4),duplicate:{isDuplicate:best.score>=78,score:best.score,adId:best.score>=78?best.id:null,reason:best.score>=78?best.reason:''}}}
function renderModerationResult(r){const box=$('#moderationResult');if(!box)return;box.hidden=false;box.className=`moderation-result ${r.action==='allow'?'safe':r.action==='review'?'review':'blocked'}`;$('#trustScoreBadge').textContent=`الثقة ${Number(r.trustScore||0)}/100`;$('#moderationSummary').textContent=r.action==='allow'?'الفحص جيد ويمكن نشر الإعلان.':r.action==='review'?'سيتم إرسال الإعلان للمراجعة قبل ظهوره للعامة.':'تعذر نشر الإعلان تلقائيًا بسبب مؤشرات خطورة مرتفعة.';$('#moderationReasons').innerHTML=(r.reasons||[]).map(x=>`<li>${esc(x)}</li>`).join('');const dup=$('#duplicateAdNotice');if(r.duplicate?.isDuplicate){dup.hidden=false;dup.innerHTML=`إعلان مشابه بنسبة <strong>${Number(r.duplicate.score||0)}%</strong>${r.duplicate.adId?` — رقم الإعلان ${esc(r.duplicate.adId)}`:''}. يفضّل تحديث إعلانك السابق بدل التكرار.`}else dup.hidden=true}
async function moderateAdBeforePublish(ad){const candidates=ads.slice(0,80).map(x=>({id:x.id,user_id:x.user_id,title:x.title,category:x.category,price:x.price,governorate:x.governorate,area:x.area,description:x.description,phone:x.phone}));try{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),18000);const res=await fetch('/api/ai',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:'moderate',text:`${ad.title} ${ad.description}`,ad,candidates}),signal:controller.signal});clearTimeout(timer);const payload=await res.json().catch(()=>({}));if(!res.ok||!payload.ok)throw new Error(payload.error||`AI HTTP ${res.status}`);return payload.data}catch(error){console.warn('Moderation fallback:',error.message);return localModeration(ad,candidates)}}
$('#adForm').onsubmit=async e=>{
  e.preventDefault();if(isPublishing)return;if(!await requireAuth())return;
  const form=e.currentTarget,btn=$('#adSubmit'),status=$('#publishStatus');
  const showStatus=(text,type='')=>{status.hidden=false;status.textContent=text;status.className=`publish-status ${type}`.trim()};
  isPublishing=true;btn.disabled=true;showStatus('جاري حفظ الإعلان...');
  try{
    const d=new FormData(form);const payload={user_id:session.user.id,title:String(d.get('title')).trim(),category:String(d.get('category')),price:Number(d.get('price'))||0,governorate:String(d.get('governorate')),area:String(d.get('area')).trim(),description:String(d.get('description')).trim(),phone:String(d.get('phone')).trim(),status:'active'};
    if(!payload.title||!payload.category||!payload.governorate||!payload.area||!payload.description||!payload.phone)throw new Error('أكمل جميع الحقول المطلوبة.');
    showStatus('جاري فحص الأمان والتكرار...');const moderation=await moderateAdBeforePublish(payload);renderModerationResult(moderation);
    if(moderation.action==='block')throw new Error('تعذر النشر: عدّل الإعلان وأزل مؤشرات الخطورة الموضحة ثم حاول مجددًا.');
    Object.assign(payload,{trust_score:moderation.trustScore,risk_score:moderation.riskScore,moderation_status:moderation.action==='review'?'pending':'approved',moderation_reasons:moderation.reasons||[],duplicate_of:moderation.duplicate?.adId||null,duplicate_score:moderation.duplicate?.score||0,status:moderation.action==='review'?'under_review':'active'});
    let r;if(editingAdId)r=await sb.from('ads').update(payload).eq('id',editingAdId).eq('user_id',session.user.id).select('*').single();else r=await sb.from('ads').insert(payload).select('*').single();
    if(r.error)throw r.error;const ad=r.data;if(!ad?.id)throw new Error('لم يرجع رقم الإعلان من قاعدة البيانات.');
    const files=[...form.elements.images.files].slice(0,5);if(files.length){showStatus('تم حفظ الإعلان، جاري رفع الصور...');await uploadImages(ad.id,files)}
    await verifyAd(ad.id);rememberPublishedImageHashes();if(payload.status==='under_review'){showStatus('تم حفظ الإعلان وإرساله للمراجعة. سيظهر بعد الموافقة.','success');setTimeout(()=>{form.reset();clearAdDraft();$('#adDialog').close();editingAdId=null;status.hidden=true;openAccount()},900)}else{showStatus('تم نشر الإعلان وظهر في السوق.','success');await loadAds();const published=ads.find(x=>Number(x.id)===Number(ad.id));if(!published)throw new Error('تم حفظ الإعلان لكن لم يظهر في النتائج بعد. حدّث الصفحة.');setTimeout(()=>{form.reset();clearAdDraft();$('#adDialog').close();editingAdId=null;status.hidden=true;openDetails(ad.id)},500)}
  }catch(error){console.error('Publish error:',error);showStatus(error?.message||'تعذر نشر الإعلان.','error')}
  finally{isPublishing=false;btn.disabled=false;btn.textContent=editingAdId?'حفظ التعديل':'نشر الإعلان'}
};
async function openSellerProfile(userId){
  const dialog=$('#sellerDialog');
  $('#sellerName').textContent='جاري تحميل بيانات البائع...';
  $('#sellerMeta').textContent='';$('#sellerActions').innerHTML='';$('#sellerAds').innerHTML='';dialog.showModal();
  const [{data:profile,error:profileError},{data:sellerRows,error:adsError}]=await Promise.all([sb.from('profiles').select('*').eq('id',userId).single(),sb.from('ads').select('*').eq('user_id',userId).eq('status','active').order('created_at',{ascending:false})]);
  if(profileError&&profileError.code!=='PGRST116')console.warn('Seller profile:',profileError.message);
  if(adsError){$('#sellerName').textContent='تعذر تحميل البائع';$('#sellerAds').textContent=adsError.message;return}
  const name=profile?.name||'مستخدم Ask Jordan';const phone=profile?.phone||sellerRows?.[0]?.phone||'';
  $('#sellerName').textContent=name;const joined=profile?.created_at?new Date(profile.created_at).toLocaleDateString('ar-JO',{year:'numeric',month:'long'}):'';
  $('#sellerMeta').textContent=`${sellerRows?.length||0} إعلان نشط${joined?` · عضو منذ ${joined}`:''}`;
  $('#sellerActions').innerHTML=phone?`<a href="tel:${esc(phone)}">اتصال</a><a href="${waLink(phone)}" target="_blank" rel="noopener">واتساب</a>`:'';
  $('#sellerAds').innerHTML=sellerRows?.length?sellerRows.map(a=>`<button type="button" class="seller-ad-item" data-seller-ad="${a.id}"><strong>${esc(a.title)}</strong><span>${money(a.price)} · ${esc(a.governorate)}</span></button>`).join(''):'<p>لا توجد إعلانات نشطة لهذا البائع.</p>';
  document.querySelectorAll('[data-seller-ad]').forEach(b=>b.onclick=()=>{dialog.close();openDetails(Number(b.dataset.sellerAd))});
}


function shortTime(value){if(!value)return '';const d=new Date(value),now=new Date(),same=d.toDateString()===now.toDateString();return same?d.toLocaleTimeString('ar-JO',{hour:'2-digit',minute:'2-digit'}):d.toLocaleDateString('ar-JO',{month:'short',day:'numeric'})}
async function updateNotificationBadge(){
  const badge=$('#notificationBadge');if(!badge)return;
  if(!session){badge.hidden=true;return}
  const {count,error}=await sb.from('notifications').select('id',{count:'exact',head:true}).eq('user_id',session.user.id).is('read_at',null);
  if(error){console.warn('Unread notifications:',error.message);badge.hidden=true;return}
  badge.textContent=Number(count||0)>99?'99+':String(count||0);badge.hidden=!count;
}
function notificationIcon(type){return type==='message'?'💬':type==='saved_search_match'?'🔎':'🔔'}
async function renderNotifications(){
  const box=$('#notificationsList');box.innerHTML='<p class="hint">جاري تحميل الإشعارات...</p>';
  const {data,error}=await sb.from('notifications').select('*').eq('user_id',session.user.id).order('created_at',{ascending:false}).limit(100);
  if(error){box.innerHTML=`<p class="hint">${esc(error.message)}</p>`;return}
  const rows=data||[];
  box.innerHTML=rows.length?rows.map(n=>`<button type="button" class="notification-item ${n.read_at?'':'unread'}" data-notification="${n.id}" data-type="${esc(n.type)}" data-ad="${n.ad_id||''}" data-conversation="${n.conversation_id||''}"><span class="notification-icon">${notificationIcon(n.type)}</span><span><strong>${esc(n.title)}</strong><small>${esc(n.body||'')} · ${shortTime(n.created_at)}</small></span>${n.read_at?'':'<i></i>'}</button>`).join(''):'<p class="hint">لا توجد إشعارات حاليًا.</p>';
  box.querySelectorAll('[data-notification]').forEach(b=>b.onclick=async()=>{
    await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',b.dataset.notification).eq('user_id',session.user.id);
    await updateNotificationBadge();
    $('#notificationsDialog').close();
    if(b.dataset.type==='message'&&b.dataset.conversation){$('#messagesDialog').showModal();await renderConversationList(Number(b.dataset.conversation));await openConversation(Number(b.dataset.conversation));return}
    if(b.dataset.ad)openDetails(Number(b.dataset.ad));
  });
}
async function subscribeNotifications(){
  if(notificationChannel){await sb.removeChannel(notificationChannel);notificationChannel=null}
  if(!session)return;
  notificationChannel=sb.channel(`notifications-${session.user.id}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:`user_id=eq.${session.user.id}`},payload=>{
    updateNotificationBadge();
    const n=payload.new;
    if(document.visibilityState==='visible'){
      const toast=document.createElement('button');toast.type='button';toast.className='notification-toast';toast.innerHTML=`<span>${notificationIcon(n.type)}</span><div><strong>${esc(n.title)}</strong><small>${esc(n.body||'')}</small></div>`;
      toast.onclick=()=>{$('#notificationsBtn').click();toast.remove()};document.body.appendChild(toast);setTimeout(()=>toast.remove(),6500);
    }
  }).subscribe();
}
async function updateUnreadBadge(){
  const badge=$('#messageBadge');if(!badge)return;
  if(!session){badge.hidden=true;return}
  const {count,error}=await sb.from('messages').select('id',{count:'exact',head:true}).neq('sender_id',session.user.id).is('read_at',null);
  if(error){console.warn('Unread messages:',error.message);badge.hidden=true;return}
  badge.textContent=Number(count||0)>99?'99+':String(count||0);badge.hidden=!count;
}
async function getConversationRows(){
  const {data,error}=await sb.from('conversations').select('*').order('last_message_at',{ascending:false});
  if(error)throw error;return data||[];
}
async function renderConversationList(openId=null){
  const box=$('#conversationList');box.innerHTML='<p class="hint">جاري تحميل المحادثات...</p>';
  const rows=await getConversationRows();
  if(!rows.length){box.innerHTML='<p class="hint">لا توجد محادثات بعد. افتح إعلانًا واضغط «مراسلة البائع».</p>';return}
  const userIds=[...new Set(rows.flatMap(r=>[r.buyer_id,r.seller_id]).filter(Boolean))];
  const {data:profiles}=await sb.from('profiles').select('id,name').in('id',userIds);
  const names=new Map((profiles||[]).map(p=>[p.id,p.name||'مستخدم Ask Jordan']));
  const ids=rows.map(r=>r.id);const {data:lastMsgs}=await sb.from('messages').select('conversation_id,body,created_at,sender_id,read_at').in('conversation_id',ids).order('created_at',{ascending:false});
  const latest=new Map();for(const m of lastMsgs||[])if(!latest.has(m.conversation_id))latest.set(m.conversation_id,m);
  box.innerHTML=rows.map(r=>{const other=r.buyer_id===session.user.id?r.seller_id:r.buyer_id,a=ads.find(x=>Number(x.id)===Number(r.ad_id)),m=latest.get(r.id),active=Number(r.id)===Number(currentConversationId);return `<button type="button" class="conversation-item ${active?'active':''}" data-conversation="${r.id}"><strong>${esc(names.get(other)||'مستخدم Ask Jordan')}</strong><span>${esc(a?.title||'إعلان')}</span><small>${esc(m?.body||'ابدأ المحادثة')}${m?.created_at?` · ${shortTime(m.created_at)}`:''}</small></button>`}).join('');
  document.querySelectorAll('[data-conversation]').forEach(b=>b.onclick=()=>openConversation(Number(b.dataset.conversation)));
  if(openId)await openConversation(openId);else if(!currentConversationId&&rows[0])await openConversation(rows[0].id);
}
async function openConversation(id){
  currentConversationId=Number(id);$('#chatEmpty').hidden=true;$('#chatActive').hidden=false;
  const {data:conv,error}=await sb.from('conversations').select('*').eq('id',id).single();if(error){alert(error.message);return}
  const other=conv.buyer_id===session.user.id?conv.seller_id:conv.buyer_id;
  const [{data:profile},{data:messages,error:msgError}]=await Promise.all([sb.from('profiles').select('name').eq('id',other).maybeSingle(),sb.from('messages').select('*').eq('conversation_id',id).order('created_at',{ascending:true})]);
  if(msgError){alert(msgError.message);return}
  const ad=ads.find(x=>Number(x.id)===Number(conv.ad_id));$('#chatHeader').innerHTML=`<strong>${esc(profile?.name||'مستخدم Ask Jordan')}</strong><span>${esc(ad?.title||'الإعلان')}</span>`;
  $('#chatMessages').innerHTML=(messages||[]).length?(messages||[]).map(m=>`<div class="chat-message ${m.sender_id===session.user.id?'mine':'theirs'}"><p>${esc(m.body)}</p><small>${shortTime(m.created_at)}${m.sender_id===session.user.id?(m.read_at?' · تمت القراءة':' · تم الإرسال'):''}</small></div>`).join(''):'<p class="hint">ابدأ المحادثة برسالة ترحيب.</p>';
  $('#chatMessages').scrollTop=$('#chatMessages').scrollHeight;
  await sb.from('messages').update({read_at:new Date().toISOString()}).eq('conversation_id',id).neq('sender_id',session.user.id).is('read_at',null);
  document.querySelectorAll('[data-conversation]').forEach(b=>b.classList.toggle('active',Number(b.dataset.conversation)===Number(id)));
  subscribeMessages(id);updateUnreadBadge();
}
function subscribeMessages(id){
  if(messageChannel)sb.removeChannel(messageChannel);
  messageChannel=sb.channel(`conversation-${id}`).on('postgres_changes',{event:'*',schema:'public',table:'messages',filter:`conversation_id=eq.${id}`},()=>openConversation(id)).subscribe();
}
async function startConversation(ad){
  if(!await requireAuth())return;if(ad.user_id===session.user.id){alert('هذا إعلانك، لا يمكنك مراسلة نفسك.');return}
  const {data,error}=await sb.rpc('get_or_create_conversation',{p_ad_id:Number(ad.id)});if(error){alert(error.message);return}
  $('#detailsDialog').close();$('#messagesDialog').showModal();await renderConversationList(Number(data));
}
$('#notificationsBtn').onclick=async()=>{if(!await requireAuth())return;$('#notificationsDialog').showModal();await renderNotifications()};
$('#markAllNotifications').onclick=async()=>{if(!session)return;const {error}=await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('user_id',session.user.id).is('read_at',null);if(error)alert(error.message);else{await updateNotificationBadge();await renderNotifications()}};
$('#messagesBtn').onclick=async()=>{if(!await requireAuth())return;$('#messagesDialog').showModal();await renderConversationList()};
$('#chatForm').onsubmit=async e=>{e.preventDefault();if(!currentConversationId)return;const input=$('#chatInput'),body=input.value.trim();if(!body)return;input.value='';const {error}=await sb.from('messages').insert({conversation_id:currentConversationId,sender_id:session.user.id,body});if(error){alert(error.message);input.value=body;return}await sb.from('conversations').update({last_message_at:new Date().toISOString()}).eq('id',currentConversationId);await openConversation(currentConversationId)};

function openDetails(id){const a=ads.find(x=>Number(x.id)===Number(id));if(!a)return;currentDetail=a;currentImageIndex=0;trackAdAction(a.id,'views');renderDetail();history.replaceState(null,'',`#ad-${a.id}`);$('#detailsDialog').showModal()}
function renderDetail(){const a=currentDetail,imgs=adImages(a);$('#detailTitle').textContent=a.title;$('#detailPrice').textContent=money(a.price);const stats=adAnalytics(a.id);$('#detailMeta').textContent=`${a.category} · ${a.governorate} · ${a.area} · 👁 ${stats.views}`;$('#detailDescription').textContent=a.description;$('#detailCall').href=`tel:${a.phone}`;$('#detailWhatsapp').href=waLink(a.phone);$('#detailCounter').textContent=imgs.length?`${currentImageIndex+1} / ${imgs.length}`:'';$('#detailImage').src=imgs[currentImageIndex]?.image_url||'';$('#detailImage').hidden=!imgs.length;$('#detailPlaceholder').hidden=!!imgs.length;$('#prevImage').hidden=imgs.length<2;$('#nextImage').hidden=imgs.length<2;document.title=`${a.title} | Ask Jordan`;const related=ads.filter(x=>x.id!==a.id&&(x.category===a.category||x.governorate===a.governorate)).slice(0,4);$('#relatedAds').innerHTML=related.length?related.map(x=>`<button type="button" data-related="${x.id}"><strong>${esc(x.title)}</strong><span>${money(x.price)} · ${esc(x.governorate)}</span></button>`).join(''):'<p>لا توجد إعلانات مشابهة حاليًا.</p>';document.querySelectorAll('[data-related]').forEach(b=>b.onclick=()=>openDetails(Number(b.dataset.related)));updateDetailFavorite()}
$('#prevImage').onclick=()=>{const n=adImages(currentDetail).length;if(!n)return;currentImageIndex=(currentImageIndex-1+n)%n;renderDetail()};
$('#nextImage').onclick=()=>{const n=adImages(currentDetail).length;if(!n)return;currentImageIndex=(currentImageIndex+1)%n;renderDetail()};
$('#detailMessage').onclick=()=>startConversation(currentDetail);$('#detailCall').onclick=()=>trackAdAction(currentDetail.id,'calls');$('#detailWhatsapp').onclick=()=>trackAdAction(currentDetail.id,'whatsapp');$('#detailShare').onclick=()=>shareAd(currentDetail.id);$('#detailFavorite').onclick=()=>toggleFavorite(currentDetail.id);$('#detailSeller').onclick=()=>openSellerProfile(currentDetail.user_id);$('#detailsDialog').addEventListener('close',()=>{if(location.hash.startsWith('#ad-'))history.replaceState(null,'',location.pathname+location.search);document.title='Ask Jordan | اسأل السوق الأردني'});
async function shareAd(id){trackAdAction(id,'shares');const a=ads.find(x=>Number(x.id)===Number(id));if(!a)return;const text=`${a.title}\n${money(a.price)}\n${a.governorate} - ${a.area}\n${location.origin}`;try{if(navigator.share)await navigator.share({title:a.title,text,url:location.origin});else{await navigator.clipboard.writeText(text);alert('تم نسخ تفاصيل الإعلان')}}catch(e){if(e.name!=='AbortError')alert('تعذر المشاركة')}}
$('#accountBtn').onclick=async()=>{
  if(!await requireAuth())return;
  const [{data:p},{data:mine,error},{data:savedSearches,error:savedError}]=await Promise.all([
    sb.from('profiles').select('*').eq('id',session.user.id).single(),
    sb.from('ads').select('*').eq('user_id',session.user.id).order('created_at',{ascending:false}),
    sb.from('saved_searches').select('*').eq('user_id',session.user.id).order('created_at',{ascending:false})
  ]);
  if(error||savedError){alert((error||savedError).message);return}
  $('#identity').textContent=`${p?.name||'مستخدم'} · ${p?.phone||''}`;
  const own=mine||[],activeCount=own.filter(a=>a.status==='active').length;
  const totals=own.reduce((sum,a)=>{const x=adAnalytics(a.id);sum.views+=x.views;sum.whatsapp+=x.whatsapp;sum.calls+=x.calls;sum.shares+=x.shares;return sum},{views:0,whatsapp:0,calls:0,shares:0});
  $('#sellerDashboard').innerHTML=`<div><strong>${activeCount}</strong><span>إعلانات نشطة</span></div><div><strong>${totals.views}</strong><span>مشاهدات</span></div><div><strong>${totals.whatsapp}</strong><span>نقرات واتساب</span></div><div><strong>${totals.calls}</strong><span>نقرات اتصال</span></div>`;
  const favAds=ads.filter(a=>isFavorite(a.id));
  $('#favoriteSummary').textContent=favAds.length?`لديك ${favAds.length} إعلان محفوظ`:'لا توجد إعلانات محفوظة';
  $('#favoriteAds').innerHTML=favAds.length?favAds.map(a=>`<button type="button" class="favorite-account-item" data-favorite-open="${a.id}"><strong>${esc(a.title)}</strong><span>${money(a.price)} · ${esc(a.governorate)}</span></button>`).join(''):'<p class="hint">احفظ أي إعلان من زر القلب وسيظهر هنا.</p>';
  document.querySelectorAll('[data-favorite-open]').forEach(b=>b.onclick=()=>{$('#accountDialog').close();openDetails(Number(b.dataset.favoriteOpen))});
  const saved=(savedSearches||[]).map(row=>{const intent=hydrateIntent(row),matches=searchAdsFromIntent(intent).results,newMatches=matches.filter(a=>new Date(a.created_at)>new Date(row.last_seen_at||row.created_at));return {...row,intent,matches,newMatches}});
  $('#savedSearches').innerHTML=saved.length?saved.map(x=>`<div class="saved-search-item"><div><strong>${esc(x.query)}</strong><small>${x.newMatches.length?`🔔 ${x.newMatches.length} إعلان جديد`:`${x.matches.length} نتيجة حالية`}</small></div><div><button type="button" class="ghost" data-run-saved="${x.id}">عرض</button><button type="button" class="danger" data-delete-saved="${x.id}">حذف</button></div></div>`).join(''):'<p class="hint">بعد أي بحث اضغط «احفظ البحث ونبّهني».</p>';
  document.querySelectorAll('[data-run-saved]').forEach(b=>b.onclick=async()=>{const x=saved.find(v=>Number(v.id)===Number(b.dataset.runSaved));if(!x)return;await sb.from('saved_searches').update({last_seen_at:new Date().toISOString()}).eq('id',x.id).eq('user_id',session.user.id);$('#accountDialog').close();$('#searchInput').value=x.query;runSmartSearch(x.query,x.intent,false);document.querySelector('#conversation')?.scrollIntoView({behavior:'smooth'})});
  document.querySelectorAll('[data-delete-saved]').forEach(b=>b.onclick=async()=>{if(!confirm('حذف البحث المحفوظ؟'))return;const {error}=await sb.from('saved_searches').delete().eq('id',b.dataset.deleteSaved).eq('user_id',session.user.id);if(error)alert(error.message);else $('#accountBtn').click()});
  $('#myAds').innerHTML=own.length?own.map(a=>{const x=adAnalytics(a.id);return `<div class="my-ad"><div><strong>${esc(a.title)}</strong><br><small>${esc(a.status)} · ${money(a.price)} · 👁 ${x.views} · واتساب ${x.whatsapp}</small></div><div class="my-ad-actions">${a.status==='active'?`<button class="promote-btn" data-promote="${a.id}">روّج إعلانك</button><button class="ghost" data-edit="${a.id}">تعديل</button><button class="danger" data-delete="${a.id}">حذف</button>`:''}</div></div>`}).join(''):'لا توجد إعلانات';
  document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=async()=>{if(!confirm('حذف الإعلان؟'))return;const {error}=await sb.from('ads').update({status:'deleted'}).eq('id',b.dataset.delete).eq('user_id',session.user.id);if(error)alert(error.message);else{$('#accountDialog').close();await loadAds()}});
  document.querySelectorAll('[data-promote]').forEach(b=>b.onclick=()=>{const a=own.find(x=>Number(x.id)===Number(b.dataset.promote));if(a){$('#accountDialog').close();openPromotionDialog(a)}});
  document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>{const a=own.find(x=>Number(x.id)===Number(b.dataset.edit));if(!a)return;editingAdId=a.id;const f=$('#adForm').elements;f.title.value=a.title;f.category.value=a.category;f.governorate.value=a.governorate;f.price.value=a.price;f.area.value=a.area;f.description.value=a.description;f.phone.value=a.phone;$('#adDialogTitle').textContent='تعديل الإعلان';$('#adSubmit').textContent='حفظ التعديل';$('#adImagesHint').hidden=false;$('#accountDialog').close();$('#adDialog').showModal()});
  $('#accountDialog').showModal()
};

$('#promotionForm').onsubmit=async e=>{
  e.preventDefault();if(!await requireAuth())return;const d=new FormData(e.currentTarget),adId=Number(d.get('ad_id')),plan=d.get('plan'),cfgPlan=PROMOTION_PLANS[plan],status=$('#promotionStatus');
  status.hidden=false;status.className='publish-status';status.textContent='جاري إرسال الطلب...';
  const {error}=await sb.from('promotion_requests').insert({ad_id:adId,user_id:session.user.id,plan,amount:cfgPlan.amount,status:'pending'});
  if(error){status.className='publish-status error';status.textContent=error.message;return}
  status.className='publish-status success';status.textContent='تم إرسال الطلب. سيفتح واتساب لإتمام الدفع.';
  const ad=ads.find(x=>Number(x.id)===adId),msg=`طلب ترويج إعلان في Ask Jordan%0Aالإعلان: ${encodeURIComponent(ad?.title||adId)}%0Aالباقة: ${encodeURIComponent(cfgPlan.label)}%0Aالمبلغ: ${cfgPlan.amount} دينار%0Aرقم الطلب سيتم مراجعته من لوحة الإدارة.`;
  setTimeout(()=>window.open(waLink(PAYMENT_PHONE)+`?text=${msg}`,'_blank','noopener'),350);
};
async function reportCurrentAd(){
  if(!currentDetail)return;
  if(!await requireAuth())return;
  const reason=prompt('اكتب سبب البلاغ باختصار:','محتوى غير مناسب');
  if(!reason?.trim())return;
  const {error}=await sb.from('reports').insert({ad_id:currentDetail.id,reporter_id:session.user.id,reason:reason.trim(),status:'open'});
  if(error){alert(error.message);return}
  alert('تم إرسال البلاغ للمراجعة. شكرًا لك.');
}
function adminStat(label,value,meta='',icon='📊',tone='blue'){return `<article class="admin-kpi ${tone}"><div class="admin-kpi-icon">${icon}</div><div><small>${esc(label)}</small><strong>${Number(value||0).toLocaleString('ar-JO')}</strong><span>${esc(meta||'')}</span></div></article>`}
function adminMoneyStat(label,value,meta='',icon='💰'){return `<article class="admin-kpi green"><div class="admin-kpi-icon">${icon}</div><div><small>${esc(label)}</small><strong>${money(value||0)}</strong><span>${esc(meta||'')}</span></div></article>`}
function dayKey(date){const d=new Date(date);return Number.isNaN(d.getTime())?'':d.toISOString().slice(0,10)}
function lastSevenDays(){const out=[];for(let i=6;i>=0;i--){const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-i);out.push({key:dayKey(d),label:d.toLocaleDateString('ar-JO',{weekday:'short'})})}return out}
function renderAdminChart(allAds=[],profiles=[]){const days=lastSevenDays();const adCounts=Object.fromEntries(days.map(d=>[d.key,0])),userCounts=Object.fromEntries(days.map(d=>[d.key,0]));for(const a of allAds){const k=dayKey(a.created_at);if(k in adCounts)adCounts[k]++}for(const u of profiles){const k=dayKey(u.created_at);if(k in userCounts)userCounts[k]++}const max=Math.max(1,...Object.values(adCounts),...Object.values(userCounts));$('#adminActivityChart').innerHTML=days.map(d=>`<div class="admin-chart-day"><div class="admin-bars"><i title="${adCounts[d.key]} إعلان" style="height:${Math.max(7,adCounts[d.key]/max*100)}%"></i><b title="${userCounts[d.key]} مستخدم" style="height:${Math.max(7,userCounts[d.key]/max*100)}%"></b></div><small>${esc(d.label)}</small></div>`).join('')+`<div class="admin-chart-legend"><span><i></i> إعلانات</span><span><b></b> مستخدمون</span></div>`}
function renderAdminGovernorates(allAds=[]){const counts={};for(const a of allAds){const g=a.governorate||'غير محدد';counts[g]=(counts[g]||0)+1}const rows=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,6),max=rows[0]?.[1]||1;$('#adminGovernorates').innerHTML=rows.length?rows.map(([name,count],i)=>`<div><span><strong>${i+1}. ${esc(name)}</strong><small>${count.toLocaleString('ar-JO')} إعلان</small></span><i><b style="width:${count/max*100}%"></b></i></div>`).join(''):'<p class="hint">لا توجد بيانات كافية.</p>'}
function renderAdminActivity(allAds=[],profiles=[],reports=[],promotions=[]){const items=[];for(const a of allAds.slice(0,8))items.push({at:a.created_at,icon:'📢',title:'إعلان جديد',text:a.title||`إعلان #${a.id}`});for(const u of profiles.slice(0,6))items.push({at:u.created_at,icon:'👤',title:'مستخدم جديد',text:u.name||u.phone||'حساب جديد'});for(const r of reports.slice(0,6))items.push({at:r.created_at,icon:'🚨',title:'بلاغ جديد',text:r.reason||`إعلان #${r.ad_id}`});for(const x of promotions.slice(0,6))items.push({at:x.created_at,icon:'💎',title:'طلب ترويج',text:`طلب بقيمة ${money(x.amount||0)}`});items.sort((a,b)=>new Date(b.at||0)-new Date(a.at||0));$('#adminLiveActivity').innerHTML=items.slice(0,9).map(x=>`<div class="admin-live-item"><span>${x.icon}</span><div><strong>${esc(x.title)}</strong><p>${esc(x.text)}</p></div><time>${x.at?relativeTime(x.at):'—'}</time></div>`).join('')||'<p class="hint">لا توجد نشاطات حديثة.</p>'}
async function renderAdminAIHealth(){const box=$('#adminAIHealth');const started=performance.now();try{const res=await fetch('/api/ai');const data=await res.json();const ms=Math.round(performance.now()-started);box.innerHTML=`<div class="ai-health-status ok"><i></i><strong>الخدمة تعمل</strong></div><dl><div><dt>النموذج</dt><dd>${esc(data.model||'حسب الإعدادات')}</dd></div><div><dt>زمن الاستجابة</dt><dd>${ms.toLocaleString('ar-JO')} ms</dd></div><div><dt>المفتاح</dt><dd>${data.keyConfigured?'مُعدّ':'غير مُعدّ'}</dd></div></dl>`}catch(e){box.innerHTML=`<div class="ai-health-status bad"><i></i><strong>تعذر الاتصال</strong></div><p class="hint">${esc(e.message)}</p>`}}
function setAdminAlerts({openReports,pendingReview,pendingPromotions,aiConfigured}){const alerts=[];if(openReports)alerts.push(`${openReports} بلاغ مفتوح`);if(pendingReview)alerts.push(`${pendingReview} إعلان بانتظار المراجعة`);if(pendingPromotions)alerts.push(`${pendingPromotions} طلب ترويج معلق`);if(aiConfigured===false)alerts.push('مفتاح OpenAI غير مُعدّ');const strip=$('#adminAlertStrip');strip.hidden=!alerts.length;strip.innerHTML=alerts.length?`<strong>يحتاج انتباهك:</strong> ${alerts.map(esc).join(' · ')}`:''}
async function openAdminPanel(fromRoute=false){
  if(!await requireAdmin())return;
  if(!fromRoute&&location.pathname!='/admin')history.pushState(null,'','/admin');
  document.body.classList.add('admin-route');
  const dialog=$('#adminDialog');if(!dialog.open)dialog.showModal();
  $('#adminStats').innerHTML='<div class="admin-skeleton"></div>'.repeat(4);$('#adminLiveActivity').innerHTML='<p>جاري التحميل...</p>';$('#adminPromotions').innerHTML='';$('#adminAds').innerHTML='';$('#adminReports').innerHTML='';$('#adminUsers').innerHTML='';
  const [adsRes,profilesRes,reportsRes,promotionsRes,messagesRes]=await Promise.all([
    sb.from('ads').select('*').order('created_at',{ascending:false}).limit(500),
    sb.from('profiles').select('id,name,phone,role,created_at').order('created_at',{ascending:false}).limit(500),
    sb.from('reports').select('*').order('created_at',{ascending:false}).limit(300),
    sb.from('promotion_requests').select('*').order('created_at',{ascending:false}).limit(300),
    sb.from('messages').select('id,created_at',{count:'exact',head:true})
  ]);
  const error=adsRes.error||profilesRes.error||reportsRes.error||promotionsRes.error;if(error){$('#adminStats').innerHTML=`<p class="admin-error">${esc(error.message)}</p>`;return}
  const allAds=adsRes.data||[],profiles=profilesRes.data||[],reports=reportsRes.data||[],promotions=promotionsRes.data||[];
  const active=allAds.filter(a=>a.status==='active').length,deleted=allAds.filter(a=>a.status==='deleted').length,openReports=reports.filter(r=>r.status==='open').length,pendingReview=allAds.filter(a=>a.status==='under_review'||a.moderation_status==='pending').length,pendingPromotions=promotions.filter(p=>p.status==='pending').length,revenue=promotions.filter(p=>p.status==='approved').reduce((s,p)=>s+Number(p.amount||0),0),today=dayKey(new Date()),todayAds=allAds.filter(a=>dayKey(a.created_at)===today).length,todayUsers=profiles.filter(p=>dayKey(p.created_at)===today).length;
  $('#adminStats').innerHTML=adminStat('المستخدمون',profiles.length,`+${todayUsers} اليوم`,'👥','blue')+adminStat('الإعلانات النشطة',active,`+${todayAds} اليوم`,'📢','purple')+adminStat('الرسائل',messagesRes.count||0,'إجمالي الرسائل','💬','orange')+adminMoneyStat('الإيراد المؤكد',revenue,'طلبات ترويج معتمدة','💰');
  renderAdminChart(allAds,profiles);renderAdminGovernorates(allAds);renderAdminActivity(allAds,profiles,reports,promotions);renderAdminAIHealth();setAdminAlerts({openReports,pendingReview,pendingPromotions});
  $('#adminLastUpdated').textContent=`آخر تحديث ${new Date().toLocaleTimeString('ar-JO',{hour:'2-digit',minute:'2-digit'})}`;
  $('#adminPromotions').innerHTML=promotions.length?promotions.map(r=>{const ad=allAds.find(a=>Number(a.id)===Number(r.ad_id)),plan=PROMOTION_PLANS[r.plan]||{label:r.plan,days:1};return `<div class="admin-row"><div><strong>${esc(ad?.title||`إعلان #${r.ad_id}`)}</strong><small>${esc(plan.label)} · ${money(r.amount)} · ${esc(r.status)}</small></div><div class="admin-row-actions">${r.status==='pending'?`<button type="button" class="primary" data-promotion-approve="${r.id}" data-ad="${r.ad_id}" data-days="${plan.days}">تأكيد الدفع</button><button type="button" class="danger" data-promotion-reject="${r.id}">رفض</button>`:'<span class="promotion-chip">'+esc(r.status)+'</span>'}</div></div>`}).join(''):'<p>لا توجد طلبات ترويج.</p>';
  $('#adminAds').innerHTML=allAds.length?allAds.map(a=>`<div class="admin-row"><div><strong>${esc(a.title)}</strong><small>${esc(a.governorate)} · ${money(a.price)} · ${statusLabel(a.status)}</small></div><div class="admin-row-actions"><button type="button" data-admin-open="${a.id}" class="ghost">فتح</button>${a.status!=='active'?`<button type="button" data-admin-status="${a.id}" data-status="active" class="ghost">إعادة نشر</button>`:''}${a.status==='active'?`<button type="button" data-admin-status="${a.id}" data-status="deleted" class="danger">إخفاء</button><button type="button" data-admin-status="${a.id}" data-status="sold" class="ghost">مباع</button>`:''}</div></div>`).join(''):'<p>لا توجد إعلانات.</p>';
  $('#adminReports').innerHTML=reports.length?reports.map(r=>{const ad=allAds.find(a=>Number(a.id)===Number(r.ad_id));return `<div class="admin-row"><div><strong>${esc(ad?.title||`إعلان #${r.ad_id}`)}</strong><small>${esc(r.reason)} · ${reportStatusLabel(r.status)}</small></div><div class="admin-row-actions"><button type="button" data-admin-open="${r.ad_id}" class="ghost">فتح الإعلان</button>${r.status==='open'?`<button type="button" data-report-status="${r.id}" data-status="reviewed" class="primary">تمت المراجعة</button><button type="button" data-report-status="${r.id}" data-status="dismissed" class="ghost">رفض البلاغ</button>`:''}</div></div>`}).join(''):'<p>لا توجد بلاغات.</p>';
  $('#adminUsers').innerHTML=profiles.length?profiles.map(p=>`<div class="admin-row"><div><strong>${esc(p.name||'مستخدم')}</strong><small>${esc(p.phone||'بدون رقم')} · ${p.role==='admin'?'مشرف':'مستخدم'} · ${p.created_at?new Date(p.created_at).toLocaleDateString('ar-JO'):''}</small></div>${p.role==='admin'?'<span class="admin-badge">مشرف</span>':''}</div>`).join(''):'<p>لا يوجد مستخدمون.</p>';
  bindAdminActions();
}
function bindAdminActions(){
  document.querySelectorAll('[data-admin-jump]').forEach(b=>b.onclick=()=>{document.querySelectorAll('.admin-nav button').forEach(x=>x.classList.toggle('active',x===b||x.dataset.adminJump===b.dataset.adminJump));document.querySelector(`#admin${b.dataset.adminJump[0].toUpperCase()+b.dataset.adminJump.slice(1)}Section`)?.scrollIntoView({behavior:'smooth',block:'start'})});
  document.querySelectorAll('[data-admin-open]').forEach(b=>b.onclick=()=>{const id=Number(b.dataset.adminOpen),a=ads.find(x=>Number(x.id)===id);if(a){$('#adminDialog').close();openDetails(id)}else alert('هذا الإعلان غير ظاهر للعامة حاليًا. استخدم إدارة الحالة من اللوحة.')});
  document.querySelectorAll('[data-admin-status]').forEach(b=>b.onclick=async()=>{const id=Number(b.dataset.adminStatus),status=b.dataset.status;if(!confirm(`تغيير حالة الإعلان إلى ${statusLabel(status)}؟`))return;const {error}=await sb.from('ads').update({status,updated_at:new Date().toISOString()}).eq('id',id);if(error)alert(error.message);else{await loadAds();await openAdminPanel()}});
  document.querySelectorAll('[data-promotion-approve]').forEach(b=>b.onclick=async()=>{if(!confirm('تأكيد الدفع وتفعيل الإعلان المميز؟'))return;const until=new Date(Date.now()+Number(b.dataset.days)*86400000).toISOString();const {error:e1}=await sb.from('ads').update({featured_until:until}).eq('id',Number(b.dataset.ad));if(e1){alert(e1.message);return}const {error:e2}=await sb.from('promotion_requests').update({status:'approved',reviewed_at:new Date().toISOString(),reviewed_by:session.user.id}).eq('id',Number(b.dataset.promotionApprove));if(e2)alert(e2.message);else{await loadAds();await openAdminPanel()}});
  document.querySelectorAll('[data-promotion-reject]').forEach(b=>b.onclick=async()=>{const {error}=await sb.from('promotion_requests').update({status:'rejected',reviewed_at:new Date().toISOString(),reviewed_by:session.user.id}).eq('id',Number(b.dataset.promotionReject));if(error)alert(error.message);else await openAdminPanel()});
  document.querySelectorAll('[data-report-status]').forEach(b=>b.onclick=async()=>{const {error}=await sb.from('reports').update({status:b.dataset.status,reviewed_at:new Date().toISOString(),reviewed_by:session.user.id}).eq('id',Number(b.dataset.reportStatus));if(error)alert(error.message);else await openAdminPanel()});
}
$('#adminRefreshBtn').onclick=()=>openAdminPanel(true);
$('#adminBtn').onclick=()=>openAdminPanel(false);
$('#adminLoginForm').onsubmit=async e=>{e.preventDefault();setAdminLoginStatus('جاري تسجيل الدخول...');const d=new FormData(e.currentTarget),phone=String(d.get('phone')||'').replace(/\D/g,''),password=String(d.get('password')||'');const {error}=await sb.auth.signInWithPassword({email:phoneToEmail(phone),password});if(error){setAdminLoginStatus(error.message,true);return}await refreshSession();if(!isAdmin()){await sb.auth.signOut();session=null;currentProfile=null;setAdminLoginStatus('تم تسجيل الدخول، لكن الحساب ليس مشرفًا.',true);return}setAdminLoginStatus();$('#adminLoginDialog').close();history.replaceState(null,'','/admin');await openAdminPanel(true)};
$('#adminLogoutBtn').onclick=async()=>{await sb.auth.signOut();session=null;currentProfile=null;updateAdminButton();$('#adminDialog').close();history.replaceState(null,'','/admin/login');openAdminLogin('تم تسجيل الخروج من لوحة الإدارة.')};
$('#adminDialog').addEventListener('cancel',e=>e.preventDefault());
window.addEventListener('popstate',()=>{if(isAdminPath())handleAdminRoute()});
$('#detailReport').onclick=reportCurrentAd;

$('#logoutBtn').onclick=async()=>{if(messageChannel)sb.removeChannel(messageChannel);if(notificationChannel)sb.removeChannel(notificationChannel);await sb.auth.signOut();session=null;currentProfile=null;updateAdminButton();updateUnreadBadge();updateNotificationBadge();closeDialogs();alert('تم تسجيل الخروج')};
(async()=>{await loadPublicStats(true);await refreshSession();await updateUnreadBadge();await updateNotificationBadge();await subscribeNotifications();await loadAds();if(isAdminPath()){await handleAdminRoute();return}const m=location.hash.match(/^#ad-(\d+)$/);if(m)openDetails(Number(m[1]))})();
