const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });

function extractOutputText(payload) {
  if (typeof payload?.output_text === "string" && payload.output_text.trim()) {
    return payload.output_text.trim();
  }
  for (const item of payload?.output || []) {
    for (const part of item?.content || []) {
      if (typeof part?.text === "string" && part.text.trim()) return part.text.trim();
    }
  }
  return "";
}

function parseJsonText(text) {
  const clean = String(text || "")
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
  try {
    return JSON.parse(clean);
  } catch {
    const start = clean.indexOf("{");
    const end = clean.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(clean.slice(start, end + 1));
    throw new Error("تعذر قراءة نتيجة الذكاء الاصطناعي.");
  }
}

async function callOpenAI(env, instructions, input) {
  if (!env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY غير مضاف في Cloudflare Secrets.");
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      authorization: `Bearer ${env.OPENAI_API_KEY}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: env.OPENAI_MODEL || "gpt-4o-mini",
      instructions,
      input,
      max_output_tokens: 700,
    }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = payload?.error?.message || `OpenAI HTTP ${response.status}`;
    throw new Error(message);
  }
  return parseJsonText(extractOutputText(payload));
}


async function callOpenAIVision(env, instructions, text, images) {
  if (!env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY غير مضاف في Cloudflare Secrets.");
  const content = [{ type: "input_text", text }];
  for (const image of images.slice(0, 3)) content.push({ type: "input_image", image_url: image, detail: "low" });
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { authorization: `Bearer ${env.OPENAI_API_KEY}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: env.OPENAI_VISION_MODEL || env.OPENAI_MODEL || "gpt-4o-mini",
      instructions,
      input: [{ role: "user", content }],
      max_output_tokens: 900,
    }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload?.error?.message || `OpenAI HTTP ${response.status}`);
  return parseJsonText(extractOutputText(payload));
}

async function handleAI(request, env) {
  if (request.method === "GET") {
    return json({
      ok: true,
      service: "Ask Jordan AI",
      runtime: "Cloudflare Workers",
      keyConfigured: Boolean(env.OPENAI_API_KEY),
    });
  }
  if (request.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ ok: false, error: "JSON غير صالح" }, 400);
  }

  const mode = body?.mode;
  const text = String(body?.text || "").trim().slice(0, 2500);
  if (!text) return json({ ok: false, error: "النص مطلوب" }, 400);

  try {
    if (mode === "search") {
      const data = await callOpenAI(
        env,
        `أنت محلل بحث لمنصة إعلانات أردنية. افهم اللهجة العربية والأخطاء الإملائية. أعد JSON فقط دون Markdown بالشكل التالي:
{"category":null,"governorate":null,"minPrice":null,"maxPrice":null,"year":null,"transmission":null,"keywords":[],"summary":"","assistantReply":""}
القيم المسموحة للتصنيف: سيارات، موبايلات، عقارات، وظائف، أثاث، أجهزة كهربائية، خدمات، متفرقات.
المحافظات: عمان، إربد، الزرقاء، البلقاء، المفرق، جرش، عجلون، مادبا، الكرك، الطفيلة، معان، العقبة.
transmission إما أوتوماتيك أو عادي أو null. الأسعار أرقام بالدينار الأردني. لا تخترع معلومة غير موجودة.
assistantReply رد عربي أردني طبيعي وقصير للمستخدم يوضح أنك فهمت طلبه وما الذي ستبحث عنه، دون الادعاء بوجود نتائج لم ترها.`,
        text,
      );
      return json({ ok: true, mode, source: "openai", model: env.OPENAI_MODEL || "gpt-4o-mini", data });
    }

    if (mode === "agent") {
      const candidates = Array.isArray(body?.candidates) ? body.candidates.slice(0, 15).map((ad) => ({
        id: ad?.id,
        title: String(ad?.title || "").slice(0, 140),
        category: String(ad?.category || "").slice(0, 60),
        governorate: String(ad?.governorate || "").slice(0, 60),
        area: String(ad?.area || "").slice(0, 80),
        price: Number(ad?.price) || null,
        description: String(ad?.description || "").slice(0, 350),
      })) : [];
      const intent = body?.intent && typeof body.intent === "object" ? body.intent : {};
      const data = await callOpenAI(
        env,
        `أنت وكيل شراء ذكي لمنصة إعلانات أردنية اسمها Ask Jordan. ستستلم طلب المستخدم وفلاتر مفهومة وقائمة إعلانات حقيقية من المنصة. أعد JSON فقط دون Markdown بالشكل:
{"assistantReply":"","rankedIds":[],"suggestedQuery":""}
رتّب فقط IDs الموجودة في القائمة من الأنسب إلى الأقل مناسبة. لا تخترع إعلانات أو أسعارًا أو مواصفات. إذا كانت القائمة فارغة، اشرح بلطف أنه لا توجد نتيجة واقترح توسيعًا منطقيًا واحدًا في suggestedQuery. إذا وجدت نتائج، اذكر عددها وعرّف أفضل خيار أو خيارين اعتمادًا على البيانات المتاحة فقط، ووضّح سبب الاختيار بجملة قصيرة. استخدم لهجة عربية أردنية طبيعية ومختصرة. لا تقل إنك تواصلت مع البائع. rankedIds يجب أن يحتوي أرقام IDs فقط. suggestedQuery يكون فارغًا عند عدم الحاجة.`,
        JSON.stringify({ userRequest: text, intent, candidates }),
      );
      const allowed = new Set(candidates.map((x) => String(x.id)));
      data.rankedIds = Array.isArray(data.rankedIds) ? data.rankedIds.filter((id) => allowed.has(String(id))) : [];
      data.assistantReply = String(data.assistantReply || "").slice(0, 1200);
      data.suggestedQuery = String(data.suggestedQuery || "").slice(0, 300);
      return json({ ok: true, mode, source: "openai", model: env.OPENAI_MODEL || "gpt-4o-mini", data });
    }


    if (mode === "compare") {
      const candidates = Array.isArray(body?.candidates) ? body.candidates.slice(0, 3).map((ad) => ({
        id: ad?.id,
        title: String(ad?.title || "").slice(0, 140),
        category: String(ad?.category || "").slice(0, 60),
        governorate: String(ad?.governorate || "").slice(0, 60),
        area: String(ad?.area || "").slice(0, 80),
        price: Number(ad?.price) || null,
        description: String(ad?.description || "").slice(0, 450),
      })) : [];
      const data = await callOpenAI(
        env,
        `أنت مساعد شراء لمنصة إعلانات أردنية. قارن فقط الإعلانات الحقيقية المرسلة إليك، ولا تخترع أي مواصفات. أعد JSON فقط بالشكل:
{"assistantReply":""}
اكتب مقارنة عربية أردنية مختصرة وسهلة: ميزة واضحة لكل إعلان، ثم اختر الأنسب حسب طلب المستخدم مع توضيح أن القرار النهائي يحتاج التأكد من البائع والمعاينة. لا تدّعي فحص المنتج ولا التواصل مع البائع.`,
        JSON.stringify({ userRequest: text, candidates }),
      );
      data.assistantReply = String(data.assistantReply || "").slice(0, 1800);
      return json({ ok: true, mode, source: "openai", model: env.OPENAI_MODEL || "gpt-4o-mini", data });
    }


    if (mode === "vision") {
      const images = Array.isArray(body?.images) ? body.images.filter(x => typeof x === "string" && x.startsWith("data:image/")).slice(0, 3) : [];
      if (!images.length) return json({ ok: false, error: "أرفق صورة واحدة على الأقل" }, 400);
      const market = Array.isArray(body?.market) ? body.market.slice(0, 30).map(ad => ({
        id: ad?.id, title: String(ad?.title || "").slice(0, 120), category: String(ad?.category || "").slice(0, 50),
        price: Number(ad?.price) || null, governorate: String(ad?.governorate || "").slice(0, 40), description: String(ad?.description || "").slice(0, 220)
      })) : [];
      const userText = String(body?.text || "").trim().slice(0, 1000);
      const data = await callOpenAIVision(
        env,
        `أنت AI Vision Seller Assistant لمنصة Ask Jordan. حلّل صور المنتج فقط، ولا تخترع أي معلومة غير ظاهرة أو مذكورة. أعد JSON فقط دون Markdown بالشكل:
{"title":"","category":"متفرقات","description":"","brand":"","model":"","color":"","condition":"","tags":[],"imageQualityScore":0,"qualityScore":0,"qualityTips":[],"detectedMultipleProducts":false,"pricing":{"recommended":null,"quickSale":null,"confidence":"منخفضة","note":""}}
التصنيف واحد من: سيارات، موبايلات، عقارات، وظائف، أثاث، أجهزة كهربائية، خدمات، متفرقات.
العنوان عربي واضح بحد أقصى 100 حرف. الوصف من جملتين إلى 4 جمل ويصف فقط ما يظهر بوضوح وما ذكره المستخدم. condition لا تضعها إلا إذا كانت الحالة قابلة للملاحظة بصريًا. tags من 2 إلى 6 كلمات. imageQualityScore وqualityScore من 0 إلى 100. pricing يعتمد فقط على قائمة السوق المرسلة، وإن لم تكن كافية أعد null وثقة منخفضة. لا تعتبر السعر الظاهر داخل صورة دليلاً موثوقًا دون نص المستخدم.`,
        JSON.stringify({ sellerText: userText, market }), images
      );
      const categories = new Set(["سيارات","موبايلات","عقارات","وظائف","أثاث","أجهزة كهربائية","خدمات","متفرقات"]);
      data.title = String(data.title || "").slice(0, 100);
      data.category = categories.has(data.category) ? data.category : "متفرقات";
      data.description = String(data.description || "").slice(0, 1200);
      for (const k of ["brand","model","color","condition"]) data[k] = String(data[k] || "").slice(0, 80);
      data.tags = Array.isArray(data.tags) ? data.tags.map(x => String(x).slice(0, 30)).filter(Boolean).slice(0, 6) : [];
      data.imageQualityScore = Math.max(0, Math.min(100, Math.round(Number(data.imageQualityScore) || 0)));
      data.qualityScore = Math.max(0, Math.min(100, Math.round(Number(data.qualityScore) || 0)));
      data.qualityTips = Array.isArray(data.qualityTips) ? data.qualityTips.map(x => String(x).slice(0, 140)).filter(Boolean).slice(0, 4) : [];
      data.detectedMultipleProducts = Boolean(data.detectedMultipleProducts);
      data.pricing = data.pricing && typeof data.pricing === "object" ? data.pricing : {};
      for (const k of ["recommended","quickSale"]) data.pricing[k] = Number.isFinite(Number(data.pricing[k])) ? Number(data.pricing[k]) : null;
      data.pricing.confidence = String(data.pricing.confidence || "منخفضة").slice(0, 30);
      data.pricing.note = String(data.pricing.note || "").slice(0, 260);
      return json({ ok: true, mode, source: "openai", model: env.OPENAI_VISION_MODEL || env.OPENAI_MODEL || "gpt-4o-mini", data });
    }

    if (mode === "polish") {
      const action = ["improve","score","translate","seo"].includes(body?.action) ? body.action : "score";
      const ad = body?.ad && typeof body.ad === "object" ? {
        title: String(body.ad.title || "").slice(0, 100), category: String(body.ad.category || "متفرقات").slice(0, 60),
        price: Number.isFinite(Number(body.ad.price)) ? Number(body.ad.price) : null, governorate: String(body.ad.governorate || "").slice(0, 50),
        area: String(body.ad.area || "").slice(0, 80), description: String(body.ad.description || "").slice(0, 1800)
      } : {};
      const data = await callOpenAI(
        env,
        `أنت AI Quality Studio لمنصة Ask Jordan. لا تخترع أي معلومة غير موجودة في الإعلان. نفّذ action المرسل وأعد JSON فقط دون Markdown.
عند improve أعد: {"title":"","description":"","qualityScore":0,"tips":[],"tags":[],"summary":""}. حسّن الصياغة بالعربية الواضحة للسوق الأردني مع الحفاظ على الحقائق.
عند score أعد: {"qualityScore":0,"breakdown":{"title":0,"description":0,"details":0,"price":0,"location":0},"tips":[]}. كل درجة من 0 إلى 100، والنصائح حتى 4.
عند translate أعد: {"translatedTitle":"","translatedDescription":"","language":"en","note":""}. ترجم للإنجليزية الطبيعية دون إضافة معلومات.
عند seo أعد: {"metaTitle":"","metaDescription":"","slug":"","keywords":[]}. metaTitle حتى 60 حرفًا، metaDescription حتى 155، slug لاتيني صغير بشرطات، keywords حتى 8.
الإعلان لمنصة إعلانات مبوبة؛ تجنب الادعاءات التسويقية المبالغ بها ولا تضف ضمانًا أو حالة أو مواصفات لم يذكرها البائع.`,
        JSON.stringify({ action, ad })
      );
      if (action === "improve") {
        data.title = String(data.title || ad.title || "").slice(0, 100);
        data.description = String(data.description || ad.description || "").slice(0, 1800);
        data.qualityScore = Math.max(0, Math.min(100, Math.round(Number(data.qualityScore) || 0)));
        data.tips = Array.isArray(data.tips) ? data.tips.map(x => String(x).slice(0, 140)).filter(Boolean).slice(0, 4) : [];
        data.tags = Array.isArray(data.tags) ? data.tags.map(x => String(x).slice(0, 30)).filter(Boolean).slice(0, 8) : [];
        data.summary = String(data.summary || "").slice(0, 260);
      } else if (action === "score") {
        data.qualityScore = Math.max(0, Math.min(100, Math.round(Number(data.qualityScore) || 0)));
        data.breakdown = data.breakdown && typeof data.breakdown === "object" ? data.breakdown : {};
        for (const k of ["title","description","details","price","location"]) data.breakdown[k] = Math.max(0, Math.min(100, Math.round(Number(data.breakdown[k]) || 0)));
        data.tips = Array.isArray(data.tips) ? data.tips.map(x => String(x).slice(0, 140)).filter(Boolean).slice(0, 4) : [];
      } else if (action === "translate") {
        data.translatedTitle = String(data.translatedTitle || "").slice(0, 120);
        data.translatedDescription = String(data.translatedDescription || "").slice(0, 2200);
        data.language = "en";
        data.note = String(data.note || "").slice(0, 220);
      } else {
        data.metaTitle = String(data.metaTitle || ad.title || "").slice(0, 60);
        data.metaDescription = String(data.metaDescription || ad.description || "").slice(0, 155);
        data.slug = String(data.slug || "ad").toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "ad";
        data.keywords = Array.isArray(data.keywords) ? data.keywords.map(x => String(x).slice(0, 40)).filter(Boolean).slice(0, 8) : [];
      }
      return json({ ok: true, mode, action, source: "openai", model: env.OPENAI_MODEL || "gpt-4o-mini", data });
    }

    if (mode === "moderate") {
      const ad = body?.ad && typeof body.ad === "object" ? {
        title: String(body.ad.title || "").slice(0, 100),
        category: String(body.ad.category || "").slice(0, 60),
        price: Number(body.ad.price) || 0,
        governorate: String(body.ad.governorate || "").slice(0, 50),
        area: String(body.ad.area || "").slice(0, 80),
        description: String(body.ad.description || "").slice(0, 1600),
        phone: String(body.ad.phone || "").slice(0, 30),
      } : {};
      const candidates = Array.isArray(body?.candidates) ? body.candidates.slice(0, 25).map(x => ({
        id: x?.id, user_id: x?.user_id, title: String(x?.title || "").slice(0, 100),
        price: Number(x?.price) || 0, category: String(x?.category || "").slice(0, 60),
        governorate: String(x?.governorate || "").slice(0, 50), area: String(x?.area || "").slice(0, 80),
        description: String(x?.description || "").slice(0, 500), phone: String(x?.phone || "").slice(0, 30)
      })) : [];
      const data = await callOpenAI(
        env,
        `أنت نظام أمان ومراجعة إعلانات لمنصة Ask Jordan. قيّم الإعلان فقط وفق البيانات المرسلة وقارن بالإعلانات الحقيقية المرشحة. لا تتهم المستخدم بجريمة ولا تخترع حقائق. أعد JSON فقط دون Markdown بالشكل:
{"riskScore":0,"trustScore":0,"riskLevel":"منخفض","action":"allow","reasons":[],"duplicate":{"isDuplicate":false,"score":0,"adId":null,"reason":""}}
العوامل: طلب عربون أو تحويل مسبق، وعود غير واقعية، ضغط واستعجال، تواصل خارج المنصة بشكل مشبوه، سعر شاذ جدًا مقارنة بمرشحين متشابهين، تكرار واضح في العنوان والوصف والهاتف والموقع. riskScore وtrustScore من 0 إلى 100. riskLevel واحد من منخفض، متوسط، مرتفع. action واحد من allow أو review أو block. استخدم block فقط عند مؤشرات قوية جدًا، وreview للحالات المريبة أو التكرار المحتمل. duplicate.score من 0 إلى 100 ولا تعتبر الإعلان مكررًا إلا عند تشابه قوي. reasons حتى 4 أسباب عربية قصيرة وواضحة.`,
        JSON.stringify({ ad, candidates })
      );
      data.riskScore = Math.max(0, Math.min(100, Math.round(Number(data.riskScore) || 0)));
      data.trustScore = Math.max(0, Math.min(100, Math.round(Number(data.trustScore) || (100 - data.riskScore))));
      data.riskLevel = ["منخفض","متوسط","مرتفع"].includes(data.riskLevel) ? data.riskLevel : (data.riskScore >= 70 ? "مرتفع" : data.riskScore >= 35 ? "متوسط" : "منخفض");
      data.action = ["allow","review","block"].includes(data.action) ? data.action : (data.riskScore >= 80 ? "block" : data.riskScore >= 45 ? "review" : "allow");
      data.reasons = Array.isArray(data.reasons) ? data.reasons.map(x => String(x).slice(0, 180)).filter(Boolean).slice(0, 4) : [];
      data.duplicate = data.duplicate && typeof data.duplicate === "object" ? data.duplicate : {};
      data.duplicate.isDuplicate = Boolean(data.duplicate.isDuplicate);
      data.duplicate.score = Math.max(0, Math.min(100, Math.round(Number(data.duplicate.score) || 0)));
      const allowedIds = new Set(candidates.map(x => String(x.id)));
      data.duplicate.adId = allowedIds.has(String(data.duplicate.adId)) ? data.duplicate.adId : null;
      data.duplicate.reason = String(data.duplicate.reason || "").slice(0, 240);
      return json({ ok: true, mode, source: "openai", model: env.OPENAI_MODEL || "gpt-4o-mini", data });
    }

    if (mode === "ad") {
      const data = await callOpenAI(
        env,
        `أنت AI Seller Assistant لمنصة Ask Jordan. حوّل وصف البائع القصير إلى مسودة إعلان احترافية، وأعد JSON فقط دون Markdown بالشكل:
{"title":"","category":"متفرقات","price":null,"governorate":"","area":"","description":"","brand":"","model":"","condition":"","tags":[],"qualityScore":0,"qualityTips":[]}
التصنيف يجب أن يكون واحدًا فقط من: سيارات، موبايلات، عقارات، وظائف، أثاث، أجهزة كهربائية، خدمات، متفرقات.
اكتب بالعربية الواضحة المناسبة للسوق الأردني. لا تخترع أي معلومة لم يذكرها المستخدم. عند غياب السعر أعد null، وعند غياب المكان أو الماركة أو الموديل أو الحالة أعد نصًا فارغًا. العنوان بحد أقصى 100 حرف، والوصف بين 2 و5 جمل. tags من 2 إلى 6 كلمات قصيرة مستخرجة من النص فقط. qualityScore رقم من 0 إلى 100 يقيس اكتمال المسودة الحالية، وqualityTips حتى 3 نصائح قصيرة عملية لتحسين الإعلان.`,
        text,
      );
      const categories = new Set(["سيارات","موبايلات","عقارات","وظائف","أثاث","أجهزة كهربائية","خدمات","متفرقات"]);
      data.title = String(data.title || "").slice(0, 100);
      data.category = categories.has(data.category) ? data.category : "متفرقات";
      data.price = Number.isFinite(Number(data.price)) ? Number(data.price) : null;
      data.governorate = String(data.governorate || "").slice(0, 40);
      data.area = String(data.area || "").slice(0, 80);
      data.description = String(data.description || "").slice(0, 1200);
      data.brand = String(data.brand || "").slice(0, 60);
      data.model = String(data.model || "").slice(0, 60);
      data.condition = String(data.condition || "").slice(0, 80);
      data.tags = Array.isArray(data.tags) ? data.tags.map(x => String(x).slice(0, 30)).filter(Boolean).slice(0, 6) : [];
      data.qualityScore = Math.max(0, Math.min(100, Math.round(Number(data.qualityScore) || 0)));
      data.qualityTips = Array.isArray(data.qualityTips) ? data.qualityTips.map(x => String(x).slice(0, 120)).filter(Boolean).slice(0, 3) : [];
      return json({ ok: true, mode, source: "openai", model: env.OPENAI_MODEL || "gpt-4o-mini", data });
    }

    return json({ ok: false, error: "mode يجب أن يكون search أو agent أو compare أو ad أو vision أو polish أو moderate" }, 400);
  } catch (error) {
    console.error("Ask Jordan AI error", error);
    return json({ ok: false, error: error?.message || "تعذر الاتصال بالذكاء الاصطناعي" }, 502);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/admin" || url.pathname === "/admin/" || url.pathname === "/admin/login" || url.pathname === "/admin/login/") {
      const adminUrl = new URL("/admin.html", url.origin);
      return env.ASSETS.fetch(new Request(adminUrl, request));
    }
    if (url.pathname === "/api/ai" || url.pathname === "/api/ai/" || url.pathname === "/api/ai/generate-ad" || url.pathname === "/api/ai/generate-ad/") {
      if (url.pathname.includes("generate-ad") && request.method === "POST") {
        const body = await request.json().catch(() => ({}));
        request = new Request(request.url, { method: "POST", headers: request.headers, body: JSON.stringify({ ...body, mode: "ad" }) });
      }
      return handleAI(request, env);
    }
    return env.ASSETS.fetch(request);
  },
};
