Ask Jordan v3.6.4 — Standalone Admin Route Fix

الإصلاح الأساسي:
- Cloudflare Workers Static Assets كان يشغّل Worker أولًا فقط لمسارات /api/*.
- تمت إضافة /admin و /admin/* إلى run_worker_first.
- تمت إضافة public/admin/index.html و public/admin/login/index.html كمسارات احتياطية ثابتة.

بعد النشر افتح:
https://YOUR-WORKER.workers.dev/admin

يجب أن تظهر لوحة مستقلة، وليس نافذة المشرف فوق الصفحة الرئيسية.
لا يوجد SQL جديد.
